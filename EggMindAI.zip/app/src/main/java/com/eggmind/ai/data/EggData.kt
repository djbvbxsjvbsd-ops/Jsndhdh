package com.eggmind.ai.data

data class Egg(val name: String, val rarity: String, val color: Int, val hint: String)

object EggData {
    val all = listOf(
        Egg("Ovo Comum",      "Comum",    0xFFFFFFFF.toInt(), "Aparece em qualquer mapa, perto do centro."),
        Egg("Ovo Raro",       "Raro",     0xFF4FC3F7.toInt(), "Perto de água e árvores."),
        Egg("Ovo Épico",      "Épico",    0xFFAB47BC.toInt(), "Zonas altas ou escondidas."),
        Egg("Ovo Lendário",   "Lendário", 0xFFFFC107.toInt(), "Áreas com brilho ou eventos."),
        Egg("Ovo Mítico",     "Mítico",   0xFFFF5252.toInt(), "Só em eventos ou mapas específicos."),
        Egg("Ovo Sorcus",     "Lendário", 0xFF81C784.toInt(), "Templo ou área central secreta."),
        Egg("Ovo Outrageous", "Épico",    0xFFFF7043.toInt(), "Prédios altos."),
        Egg("Ovo Hex",        "Mítico",   0xFF7E57C2.toInt(), "Cemitérios e áreas sombrias.")
    )
}
