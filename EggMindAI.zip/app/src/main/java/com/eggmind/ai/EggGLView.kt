package com.eggmind.ai

import android.content.Context
import android.graphics.PixelFormat
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.cos
import kotlin.math.sin

class EggGLView(context: Context) : GLSurfaceView(context) {
    private val eggRenderer = EggRenderer()

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 16, 0)
        setZOrderOnTop(true)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        setRenderer(eggRenderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun setEggColor(r: Float, g: Float, b: Float) = eggRenderer.setColor(r, g, b)
}

internal class EggRenderer : GLSurfaceView.Renderer {
    private var program = 0
    private var posH = 0
    private var nrmH = 0
    private var colorH = 0
    private var mvpH = 0
    private var modelH = 0
    private val vertices: FloatBuffer
    private val indices: ShortBuffer
    private val indexCount: Int
    private var angle = 0f
    @Volatile private var color = floatArrayOf(1f, 0.84f, 0.31f)
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val model = FloatArray(16)
    private val tmp = FloatArray(16)
    private val mvp = FloatArray(16)

    init {
        val stacks = 32
        val slices = 32
        val data = FloatArray((stacks + 1) * (slices + 1) * 6)
        var k = 0
        for (i in 0..stacks) {
            val phi = Math.PI * i / stacks
            for (j in 0..slices) {
                val theta = 2.0 * Math.PI * j / slices
                val px = (sin(phi) * cos(theta)).toFloat()
                val py = cos(phi).toFloat()
                val pz = (sin(phi) * sin(theta)).toFloat()
                val f = 1f - 0.15f * py          // mais largo embaixo, formato de ovo
                data[k++] = px * f; data[k++] = py * 1.25f; data[k++] = pz * f
                data[k++] = px;     data[k++] = py / 1.25f; data[k++] = pz
            }
        }
        val idx = ShortArray(stacks * slices * 6)
        var n = 0
        for (i in 0 until stacks) for (j in 0 until slices) {
            val a = i * (slices + 1) + j
            val b = a + slices + 1
            idx[n++] = a.toShort(); idx[n++] = b.toShort(); idx[n++] = (a + 1).toShort()
            idx[n++] = (a + 1).toShort(); idx[n++] = b.toShort(); idx[n++] = (b + 1).toShort()
        }
        indexCount = idx.size
        vertices = ByteBuffer.allocateDirect(data.size * 4).order(ByteOrder.nativeOrder())
            .asFloatBuffer().apply { put(data); position(0) }
        indices = ByteBuffer.allocateDirect(idx.size * 2).order(ByteOrder.nativeOrder())
            .asShortBuffer().apply { put(idx); position(0) }
    }

    fun setColor(r: Float, g: Float, b: Float) { color = floatArrayOf(r, g, b) }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        val vs = """
            uniform mat4 uMVP;
            uniform mat4 uModel;
            attribute vec3 aPos;
            attribute vec3 aNrm;
            varying vec3 vN;
            void main() {
                vN = (uModel * vec4(aNrm, 0.0)).xyz;
                gl_Position = uMVP * vec4(aPos, 1.0);
            }
        """.trimIndent()
        val fs = """
            precision mediump float;
            uniform vec3 uColor;
            varying vec3 vN;
            void main() {
                vec3 n = normalize(vN);
                vec3 l = normalize(vec3(0.4, 0.6, 0.7));
                float d = max(dot(n, l), 0.0);
                float s = pow(max(dot(reflect(-l, n), vec3(0.0, 0.0, 1.0)), 0.0), 24.0);
                gl_FragColor = vec4(uColor * (0.3 + 0.7 * d) + vec3(0.25 * s), 1.0);
            }
        """.trimIndent()
        program = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, compile(GLES20.GL_VERTEX_SHADER, vs))
            GLES20.glAttachShader(it, compile(GLES20.GL_FRAGMENT_SHADER, fs))
            GLES20.glLinkProgram(it)
        }
        posH = GLES20.glGetAttribLocation(program, "aPos")
        nrmH = GLES20.glGetAttribLocation(program, "aNrm")
        colorH = GLES20.glGetUniformLocation(program, "uColor")
        mvpH = GLES20.glGetUniformLocation(program, "uMVP")
        modelH = GLES20.glGetUniformLocation(program, "uModel")
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES20.glViewport(0, 0, w, h)
        Matrix.perspectiveM(proj, 0, 45f, w.toFloat() / h.coerceAtLeast(1), 0.1f, 100f)
        Matrix.setLookAtM(view, 0, 0f, 0f, 4f, 0f, 0f, 0f, 0f, 1f, 0f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClearColor(0f, 0f, 0f, 0f)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        Matrix.setIdentityM(model, 0)
        Matrix.rotateM(model, 0, angle, 0.15f, 1f, 0f)
        angle += 0.8f
        Matrix.multiplyMM(tmp, 0, view, 0, model, 0)
        Matrix.multiplyMM(mvp, 0, proj, 0, tmp, 0)

        GLES20.glUseProgram(program)
        GLES20.glUniformMatrix4fv(mvpH, 1, false, mvp, 0)
        GLES20.glUniformMatrix4fv(modelH, 1, false, model, 0)
        val c = color
        GLES20.glUniform3f(colorH, c[0], c[1], c[2])

        vertices.position(0)
        GLES20.glVertexAttribPointer(posH, 3, GLES20.GL_FLOAT, false, 24, vertices)
        GLES20.glEnableVertexAttribArray(posH)
        vertices.position(3)
        GLES20.glVertexAttribPointer(nrmH, 3, GLES20.GL_FLOAT, false, 24, vertices)
        GLES20.glEnableVertexAttribArray(nrmH)

        indices.position(0)
        GLES20.glDrawElements(GLES20.GL_TRIANGLES, indexCount, GLES20.GL_UNSIGNED_SHORT, indices)
        GLES20.glDisableVertexAttribArray(posH)
        GLES20.glDisableVertexAttribArray(nrmH)
    }

    private fun compile(type: Int, src: String): Int =
        GLES20.glCreateShader(type).also {
            GLES20.glShaderSource(it, src)
            GLES20.glCompileShader(it)
        }
}
