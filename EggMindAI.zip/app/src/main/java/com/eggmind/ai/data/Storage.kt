package com.eggmind.ai.data

import android.content.Context
import android.content.SharedPreferences

class Storage(ctx: Context) {
    private val sp: SharedPreferences =
        ctx.getSharedPreferences("eggmind", Context.MODE_PRIVATE)

    var owned: MutableSet<String>
        get() = (sp.getStringSet("owned", emptySet()) ?: emptySet()).toMutableSet()
        set(v) { sp.edit().putStringSet("owned", v).apply() }

    var timerStart: Long
        get() = sp.getLong("timerStart", 0L)
        set(v) { sp.edit().putLong("timerStart", v).apply() }

    var timerSeconds: Int
        get() = sp.getInt("timerSeconds", 60)
        set(v) { sp.edit().putInt("timerSeconds", v).apply() }

    var timerEgg: String
        get() = sp.getString("timerEgg", "") ?: ""
        set(v) { sp.edit().putString("timerEgg", v).apply() }

    var notes: String
        get() = sp.getString("notes", "") ?: ""
        set(v) { sp.edit().putString("notes", v).apply() }
}
