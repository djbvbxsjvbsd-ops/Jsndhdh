package com.eggmind.ai.ai

import com.eggmind.ai.data.EggData

class RuleAI {

    data class Ctx(val timerEgg: String, val timerSeconds: Int, val owned: Set<String>)

    fun respond(input: String, ctx: Ctx): String {
        val q = input.lowercase().trim()
        if (q.isEmpty()) return "Manda a pergunta! Ex: 'qual ovo caçar?'"
        val words = q.split(" ", ",", "!", "?", ".").filter { it.isNotEmpty() }
        val missing = EggData.all.filter { !ctx.owned.contains(it.name) }

        return when {
            words.any { it in listOf("oi", "olá", "ola", "hey", "eae") } ->
                "Opa! Sou o copiloto EggMind. Pergunte: 'qual ovo caçar?', 'o que faço agora?', 'me dá um desafio', 'o que tá faltando?'."

            q.contains("que faço") || q.contains("o que fazer") ->
                if (ctx.timerSeconds > 0)
                    "Timer do ${ctx.timerEgg.ifBlank { "ovo" }} em ${ctx.timerSeconds}s. Segura a posição e foca no spawn."
                else
                    "Sem timer ativo. Inicie um na aba ⏱️ pra eu acompanhar."

            q.contains("vale") && q.contains("esperar") -> when {
                ctx.timerSeconds in 1..20 -> "Sim — faltam ${ctx.timerSeconds}s, vale esperar."
                ctx.timerSeconds == 0 -> "Não tem timer ativo. Inicie um primeiro."
                else -> "Faltam ${ctx.timerSeconds}s. Se for raro ou melhor, vale; se comum, ignora."
            }

            q.contains("caçar") || q.contains("cacar") || q.contains("pegar") ->
                if (missing.isEmpty()) "Você completou o álbum! 🎉"
                else "Faltam ${missing.size} ovos. Sugiro '${missing.first().name}' (${missing.first().rarity}): ${missing.first().hint}"

            q.contains("falt") ->
                if (missing.isEmpty()) "Nada! Álbum completo."
                else "Faltam ${missing.size}: ${missing.take(5).joinToString { it.name }}"

            q.contains("desafio") ->
                "🎲 Desafio: " + listOf(
                    "Pegue 3 ovos raros sem morrer.",
                    "Só ande agachado pelos próximos 60s.",
                    "Não use habilidades até pegar 1 ovo.",
                    "Fique 30s parado num canto do mapa.",
                    "Corra até o ponto mais distante do mapa."
                ).random()

            else -> "Ainda tô aprendendo. Experimente: 'qual ovo caçar?', 'o que faço agora?', 'me dá um desafio', 'o que tá faltando?'."
        }
    }
}
