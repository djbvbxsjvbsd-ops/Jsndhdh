package com.eggmind.ai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import com.eggmind.ai.ai.RuleAI
import com.eggmind.ai.data.Egg
import com.eggmind.ai.data.EggData
import com.eggmind.ai.data.Storage
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var storage: Storage
    private lateinit var sidebar: View
    private lateinit var sidebarParams: WindowManager.LayoutParams
    private var panel: View? = null
    private val handler = Handler(Looper.getMainLooper())
    private val accent = Color.parseColor("#FFD54F")
    private val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        storage = Storage(this)
        startFg()
        addSidebar()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        panel?.let { runCatching { wm.removeView(it) } }
        runCatching { wm.removeView(sidebar) }
        super.onDestroy()
    }

    private fun startFg() {
        val ch = "eggmind"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "EggMind", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, ch)
            .setContentTitle("EggMind AI")
            .setContentText("Barra lateral ativa")
            .setSmallIcon(android.R.drawable.ic_menu_gallery)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else
            startForeground(1, notif)
    }

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat()
    }

    private fun tv(t: String, size: Float = 13f, color: Int = Color.WHITE) = TextView(this).apply {
        text = t; textSize = size; setTextColor(color)
    }

    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t
        isAllCaps = false
        textSize = 12f
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setTextColor(Color.WHITE)
        setPadding(dp(8), dp(4), dp(8), dp(4))
        background = bg(Color.argb(70, 255, 255, 255), 8)
        setOnClickListener { onClick() }
    }

    private fun vbox() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(6), dp(4), dp(6), dp(4))
    }

    private fun remaining(): Int {
        if (storage.timerStart == 0L) return 0
        val left = storage.timerSeconds - ((System.currentTimeMillis() - storage.timerStart) / 1000).toInt()
        return if (left > 0) left else 0
    }

    // ---------- barra lateral ----------
    private fun addSidebar() {
        sidebar = View(this).apply { background = bg(Color.argb(80, 255, 255, 255), 6) }
        sidebarParams = WindowManager.LayoutParams(
            dp(18), dp(110), overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = dp(100) }

        var downX = 0f
        var downY = 0f
        var moved = false
        sidebar.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    if (e.rawX - downX > dp(30)) {
                        showPanel()
                    } else if (abs(e.rawY - downY) > dp(8)) {
                        moved = true
                        sidebarParams.y = (e.rawY - dp(55)).toInt()
                        wm.updateViewLayout(sidebar, sidebarParams)
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved && abs(e.rawX - downX) < dp(5)) showPanel()
            }
            true
        }
        wm.addView(sidebar, sidebarParams)
    }

    // ---------- painel ----------
    private fun showPanel() {
        if (panel != null) return
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(Color.argb(220, 14, 14, 20), 16)
            setPadding(dp(6), dp(6), dp(6), dp(6))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(tv("🥚 EggMind", 14f, accent), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(btn("✕") { hidePanel() })

        val content = FrameLayout(this)
        val tabs: List<Pair<String, () -> View>> = listOf(
            "🥚 Dex" to { tabDex() },
            "⏱️ Timer" to { tabTimer() },
            "🎲 Roleta" to { tabRoulette() },
            "🧭 Mapa" to { tabMap() },
            "🎨 3D" to { tab3D() },
            "🔮 IA" to { tabAI() }
        )
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val buttons = ArrayList<Button>()
        fun select(i: Int) {
            handler.removeCallbacksAndMessages(null)
            content.removeAllViews()
            content.addView(tabs[i].second())
            buttons.forEachIndexed { k, b -> b.alpha = if (k == i) 1f else 0.55f }
        }
        tabs.forEachIndexed { i, t ->
            val b = btn(t.first) { select(i) }
            buttons.add(b)
            bar.addView(b, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { rightMargin = dp(4) })
        }

        root.addView(header)
        root.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(bar) })
        val h = minOf(dp(280), resources.displayMetrics.heightPixels - dp(120))
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, h))
        select(0)

        val p = WindowManager.LayoutParams(
            dp(300), ViewGroup.LayoutParams.WRAP_CONTENT, overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12); y = dp(40)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(root, p)
        panel = root
        sidebar.visibility = View.GONE
    }

    private fun hidePanel() {
        handler.removeCallbacksAndMessages(null)
        panel?.let { runCatching { wm.removeView(it) } }
        panel = null
        sidebar.visibility = View.VISIBLE
    }

    // ---------- abas ----------
    private fun tabDex(): View {
        val col = vbox()
        val owned = storage.owned
        val counter = tv("", 12f, accent)
        fun upd() { counter.text = "Álbum: ${owned.size}/${EggData.all.size}" }
        upd()
        col.addView(counter)
        EggData.all.forEach { egg ->
            col.addView(CheckBox(this).apply {
                text = "${egg.name} • ${egg.rarity}"
                setTextColor(egg.color)
                textSize = 13f
                isChecked = owned.contains(egg.name)
                setOnCheckedChangeListener { _, c ->
                    if (c) owned.add(egg.name) else owned.remove(egg.name)
                    storage.owned = owned
                    upd()
                }
            })
            col.addView(tv(egg.hint, 11f, Color.LTGRAY).apply { setPadding(dp(32), 0, 0, dp(4)) })
        }
        return ScrollView(this).apply { addView(col) }
    }

    private fun tabTimer(): View {
        val col = vbox()
        var idx = EggData.all.indexOfFirst { it.name == storage.timerEgg }.coerceAtLeast(0)
        val status = tv("", 22f, accent)
        val eggBtn = btn("Ovo: ${EggData.all[idx].name} ▸") {}
        eggBtn.setOnClickListener {
            idx = (idx + 1) % EggData.all.size
            eggBtn.text = "Ovo: ${EggData.all[idx].name} ▸"
        }
        val secs = EditText(this).apply {
            setText(storage.timerSeconds.toString())
            inputType = InputType.TYPE_CLASS_NUMBER
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            hint = "segundos"
            textSize = 14f
        }
        val tick = object : Runnable {
            override fun run() {
                val r = remaining()
                status.text = when {
                    storage.timerStart == 0L -> "Sem timer"
                    r > 0 -> "${storage.timerEgg}: ${r}s"
                    else -> "🥚 ${storage.timerEgg} spawnou!"
                }
                handler.postDelayed(this, 1000)
            }
        }
        val start = btn("▶ Iniciar") {
            storage.timerEgg = EggData.all[idx].name
            storage.timerSeconds = secs.text.toString().toIntOrNull()?.coerceIn(1, 86400) ?: 60
            storage.timerStart = System.currentTimeMillis()
        }
        val stop = btn("⏹ Parar") { storage.timerStart = 0L }

        col.addView(status)
        col.addView(eggBtn)
        col.addView(secs)
        col.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(start); addView(stop)
        })
        handler.post(tick)
        return col
    }

    private fun tabRoulette(): View {
        val col = vbox().apply { gravity = Gravity.CENTER }
        val result = tv("Gire a roleta", 20f, accent).apply { gravity = Gravity.CENTER }
        val sub = tv("", 12f, Color.LTGRAY).apply { gravity = Gravity.CENTER }
        var spinning = false
        val go = btn("🎲 Girar") {}
        go.setOnClickListener {
            if (spinning) return@setOnClickListener
            spinning = true
            var n = 0
            val r = object : Runnable {
                override fun run() {
                    val e = EggData.all.random()
                    result.text = e.name
                    result.setTextColor(e.color)
                    sub.text = "${e.rarity} — ${e.hint}"
                    n++
                    if (n < 20) handler.postDelayed(this, 60L + n * 12L) else spinning = false
                }
            }
            handler.post(r)
        }
        col.addView(result)
        col.addView(sub)
        col.addView(go)
        return col
    }

    private fun tabMap(): View {
        val col = vbox()
        col.addView(tv("Onde procurar", 13f, accent))
        EggData.all.forEach {
            col.addView(tv("• ${it.name}: ${it.hint}", 11f, it.color).apply { setPadding(0, dp(2), 0, dp(2)) })
        }
        col.addView(tv("\nAnotações", 13f, accent))
        col.addView(EditText(this).apply {
            setText(storage.notes)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            hint = "Escreva aqui..."
            textSize = 12f
            minLines = 3
            gravity = Gravity.TOP
            doAfterTextChanged { storage.notes = it?.toString() ?: "" }
        })
        return ScrollView(this).apply { addView(col) }
    }

    private fun tab3D(): View {
        val gl = EggGLView(this)
        fun applyEgg(e: Egg) = gl.setEggColor(
            Color.red(e.color) / 255f, Color.green(e.color) / 255f, Color.blue(e.color) / 255f
        )
        applyEgg(EggData.all[0])
        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        EggData.all.forEach { e ->
            chips.addView(btn(e.name.removePrefix("Ovo ")) { applyEgg(e) }.apply { setTextColor(e.color) },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { rightMargin = dp(4) })
        }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(chips) })
        col.addView(gl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        return col
    }

    private fun tabAI(): View {
        val ai = RuleAI()
        val log = tv("🔮 Pergunte: 'qual ovo caçar?', 'o que faço agora?', 'me dá um desafio', 'o que tá faltando?'", 12f)
        val scroll = ScrollView(this).apply { addView(log) }
        val input = EditText(this).apply {
            hint = "Pergunte..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            textSize = 13f
            isSingleLine = true
        }
        fun ask() {
            val q = input.text.toString()
            if (q.isBlank()) return
            val ans = ai.respond(q, RuleAI.Ctx(storage.timerEgg, remaining(), storage.owned))
            log.append("\n\n🧑 $q\n🤖 $ans")
            input.setText("")
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(btn("➤") { ask() })
        }
        val col = vbox()
        col.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        col.addView(row)
        return col
    }
}
