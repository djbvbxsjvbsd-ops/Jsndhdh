package com.eggmind.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(64, 160, 64, 64)
        }
        layout.addView(TextView(this).apply {
            text = "🥚 EggMind AI"
            textSize = 30f
            setTextColor(0xFFFFD54F.toInt())
        })
        layout.addView(TextView(this).apply {
            text = "\nCompanheiro flutuante para Roube um Ovo.\n\n" +
                "1. Ative a barra lateral\n" +
                "2. Volte ao jogo\n" +
                "3. Arraste a barra fina da esquerda para a direita\n"
            textSize = 14f
            setTextColor(0xFFCCCCCC.toInt())
        })
        layout.addView(Button(this).apply {
            text = "▶ Ativar barra lateral"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } else startOverlay()
            }
        })
        layout.addView(Button(this).apply {
            text = "⏹ Parar barra lateral"
            setOnClickListener {
                stopService(Intent(this@MainActivity, OverlayService::class.java))
            }
        })
        setContentView(layout)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private fun startOverlay() {
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
    }
}
