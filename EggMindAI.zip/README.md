# EggMind AI
Companheiro flutuante (overlay) para Roube um Ovo: barra lateral transparente + painel com Dex, Timer, Roleta, Mapa, Ovo 3D (OpenGL) e IA offline.

## Compilar no GitHub
1. Crie um repositório e envie TODOS os arquivos deste ZIP (inclusive a pasta `.github`).
2. Aba **Actions** > **Build APK** > aguarde o check verde.
3. Abra a execução > **Artifacts** > baixe `EggMindAI-debug-apk` > instale o `.apk`.

## Usar
Abra o app, conceda "Sobrepor a outros apps", toque em **Ativar barra lateral**. Arraste a barra fina para a direita para abrir o painel.
