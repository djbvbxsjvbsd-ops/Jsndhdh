// [NiveriaStructures.java] src/main/java/com/valdoria/rpg/world/NiveriaStructures.java
package com.valdoria.rpg.world;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
public final class NiveriaStructures {
    private NiveriaStructures() {}
    // Chamado quando jogador entra em Nivéria pela primeira vez
    public static void generateAll(ServerLevel level, BlockPos playerPos) {
        BlockPos spawnBase = new BlockPos(0, getSurface(level, 0, 0), 0);
        buildVilanevada(level, spawnBase.offset(80, 0, 0));
        buildTemploGlacial(level, spawnBase.offset(-120, 0, 60));
        buildCasteloNiveria(level, spawnBase.offset(0, 0, 200));
    }
    private static int getSurface(ServerLevel level, int x, int z) {
        return level.getHeight(net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
    }
    private static void p(ServerLevel lvl, BlockPos o, int dx, int dy, int dz, BlockState b) {
        lvl.setBlock(o.offset(dx, dy, dz), b, 3);
    }
    // ===== VILA NEVADA =====
    // 5 casas de neve, poço central, fornalha, baús
    public static void buildVilanevada(ServerLevel lvl, BlockPos o) {
        int sy = getSurface(lvl, o.getX(), o.getZ());
        BlockPos base = new BlockPos(o.getX(), sy, o.getZ());
        // Chão nevado da praça
        for (int x = -12; x <= 12; x++) for (int z = -12; z <= 12; z++)
            p(lvl, base, x, 0, z, Blocks.SNOW_BLOCK.defaultBlockState());
        // Poço central
        buildPoço(lvl, base.offset(0, 1, 0));
        // 5 casas ao redor
        buildCasaNeve(lvl, base.offset(-8, 1, -8));
        buildCasaNeve(lvl, base.offset(6, 1, -8));
        buildCasaNeve(lvl, base.offset(-9, 1, 4));
        buildCasaNeve(lvl, base.offset(6, 1, 4));
        buildCasaForjador(lvl, base.offset(-1, 1, 8));
        // Tochas
        for (int[] t : new int[][]{{-12,0},{12,0},{0,-12},{0,12},{-8,8},{8,8}}) {
            p(lvl, base, t[0], 2, t[1], Blocks.TORCH.defaultBlockState());
        }
        // Sinalizar coordenadas para quest
        p(lvl, base, 0, 3, 0, Blocks.BLUE_ICE.defaultBlockState());
    }
    private static void buildCasaNeve(ServerLevel lvl, BlockPos o) {
        // Paredes 5x5x3
        for (int y = 0; y < 3; y++) {
            for (int x = 0; x < 5; x++) {
                p(lvl, o, x, y, 0, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, x, y, 4, Blocks.SNOW_BLOCK.defaultBlockState());
            }
            for (int z = 1; z < 4; z++) {
                p(lvl, o, 0, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, 4, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
            }
        }
        // Telhado
        for (int x = 0; x < 5; x++) for (int z = 0; z < 5; z++)
            p(lvl, o, x, 3, z, Blocks.SPRUCE_PLANKS.defaultBlockState());
        // Porta e janela
        p(lvl, o, 2, 0, 0, Blocks.SPRUCE_DOOR.defaultBlockState());
        p(lvl, o, 1, 1, 0, Blocks.GLASS_PANE.defaultBlockState());
        p(lvl, o, 3, 1, 0, Blocks.GLASS_PANE.defaultBlockState());
        // Interior: cama, baú, tocha
        p(lvl, o, 1, 0, 2, Blocks.RED_BED.defaultBlockState());
        p(lvl, o, 3, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 2, 2, 2, Blocks.TORCH.defaultBlockState());
    }
    private static void buildCasaForjador(ServerLevel lvl, BlockPos o) {
        // Casa maior 7x5x4 com fornalha e bigorna
        for (int y = 0; y < 4; y++) {
            for (int x = 0; x < 7; x++) {
                p(lvl, o, x, y, 0, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, x, y, 4, Blocks.SNOW_BLOCK.defaultBlockState());
            }
            for (int z = 1; z < 4; z++) {
                p(lvl, o, 0, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, 6, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
            }
        }
        for (int x = 0; x < 7; x++) for (int z = 0; z < 5; z++)
            p(lvl, o, x, 4, z, Blocks.SPRUCE_PLANKS.defaultBlockState());
        p(lvl, o, 3, 0, 0, Blocks.SPRUCE_DOOR.defaultBlockState());
        // Forja
        p(lvl, o, 1, 0, 2, Blocks.FURNACE.defaultBlockState());
        p(lvl, o, 2, 0, 2, Blocks.BLAST_FURNACE.defaultBlockState());
        p(lvl, o, 3, 0, 2, Blocks.ANVIL.defaultBlockState());
        p(lvl, o, 4, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 5, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 3, 3, 2, Blocks.TORCH.defaultBlockState());
    }
    private static void buildPoço(ServerLevel lvl, BlockPos o) {
        for (int x = -1; x <= 1; x++) for (int z = -1; z <= 1; z++) {
            if (x == 0 && z == 0) { p(lvl, o, 0, 0, 0, Blocks.WATER.defaultBlockState()); continue; }
            p(lvl, o, x, 0, z, Blocks.STONE_BRICKS.defaultBlockState());
            p(lvl, o, x, 1, z, Blocks.STONE_BRICKS.defaultBlockState());
        }
        // Telhado do poço
        p(lvl, o, -1, 2, 0, Blocks.SPRUCE_FENCE.defaultBlockState());
        p(lvl, o, 1, 2, 0, Blocks.SPRUCE_FENCE.defaultBlockState());
        p(lvl, o, 0, 3, 0, Blocks.OAK_SLAB.defaultBlockState());
    }
    // ===== TEMPLO GLACIAL =====
    // Templo de 21x21 com 4 cristais, biblioteca e altar
    public static void buildTemploGlacial(ServerLevel lvl, BlockPos o) {
        int sy = getSurface(lvl, o.getX(), o.getZ());
        BlockPos base = new BlockPos(o.getX(), sy, o.getZ());
        // Fundação de blue ice
        for (int x = -10; x <= 10; x++) for (int z = -10; z <= 10; z++)
            p(lvl, base, x, 0, z, Blocks.BLUE_ICE.defaultBlockState());
        // Paredes 6 blocos altura de packed ice
        for (int y = 1; y <= 6; y++) {
            for (int x = -10; x <= 10; x++) {
                p(lvl, base, x, y, -10, Blocks.PACKED_ICE.defaultBlockState());
                p(lvl, base, x, y, 10, Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z = -9; z <= 9; z++) {
                p(lvl, base, -10, y, z, Blocks.PACKED_ICE.defaultBlockState());
                p(lvl, base, 10, y, z, Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        // Teto de ice
        for (int x = -10; x <= 10; x++) for (int z = -10; z <= 10; z++)
            p(lvl, base, x, 7, z, Blocks.ICE.defaultBlockState());
        // Portão (entrada sul)
        for (int y = 1; y <= 4; y++) for (int x = -2; x <= 2; x++)
            p(lvl, base, x, y, -10, Blocks.AIR.defaultBlockState());
        // 4 cristais de gelo nos quadrantes (quest 74)
        for (int[] c : new int[][]{{-5,5},{5,5},{-5,-5},{5,-5}}) {
            for (int cy = 1; cy <= 3; cy++)
                p(lvl, base, c[0], cy, c[1], Blocks.BLUE_ICE.defaultBlockState());
            p(lvl, base, c[0], 4, c[1], Blocks.BEACON.defaultBlockState());
        }
        // Altar central
        p(lvl, base, 0, 1, 0, Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
        p(lvl, base, 0, 2, 0, Blocks.ENCHANTING_TABLE.defaultBlockState());
        // Biblioteca (quest 76 — baú com livro)
        for (int bx = -8; bx <= -5; bx++) {
            p(lvl, base, bx, 1, 7, Blocks.BOOKSHELF.defaultBlockState());
            p(lvl, base, bx, 2, 7, Blocks.BOOKSHELF.defaultBlockState());
        }
        p(lvl, base, -6, 1, 6, Blocks.CHEST.defaultBlockState()); // baú do livro (quest 76)
        // Tochas
        for (int[] t : new int[][]{{-9,0},{9,0},{0,-9},{0,9},{-7,-7},{7,-7},{-7,7},{7,7}}) {
            p(lvl, base, t[0], 3, t[1], Blocks.TORCH.defaultBlockState());
        }
        // Torres nos cantos
        for (int[] c : new int[][]{{-10,-10},{10,-10},{-10,10},{10,10}}) {
            for (int ty = 7; ty <= 12; ty++)
                p(lvl, base, c[0], ty, c[1], Blocks.PACKED_ICE.defaultBlockState());
            p(lvl, base, c[0], 13, c[1], Blocks.BLUE_ICE.defaultBlockState());
        }
        // Forja Glacial (quest 79)
        p(lvl, base, 7, 1, -7, Blocks.BLAST_FURNACE.defaultBlockState());
        p(lvl, base, 8, 1, -7, Blocks.ANVIL.defaultBlockState());
        p(lvl, base, 7, 1, -8, Blocks.BLUE_ICE.defaultBlockState());
        p(lvl, base, 8, 1, -8, Blocks.CHEST.defaultBlockState());
    }
    // ===== CASTELO DE NIVÉRIA =====
    // Castelo 51x51, torres altas, salão do trono com trono de gelo
    public static void buildCasteloNiveria(ServerLevel lvl, BlockPos o) {
        int sy = getSurface(lvl, o.getX(), o.getZ());
        BlockPos base = new BlockPos(o.getX(), sy, o.getZ());
        // Fosso de gelo
        for (int x = -27; x <= 27; x++) for (int z = -27; z <= 27; z++) {
            if (Math.abs(x) >= 24 || Math.abs(z) >= 24) {
                p(lvl, base, x, -1, z, Blocks.BLUE_ICE.defaultBlockState());
                p(lvl, base, x, -2, z, Blocks.BLUE_ICE.defaultBlockState());
            }
        }
        // Fundação
        for (int x = -25; x <= 25; x++) for (int z = -25; z <= 25; z++)
            p(lvl, base, x, 0, z, Blocks.BLUE_ICE.defaultBlockState());
        // Muralhas externas 8 blocos
        for (int y = 1; y <= 8; y++) {
            for (int x = -25; x <= 25; x++) {
                p(lvl, base, x, y, -25, Blocks.PACKED_ICE.defaultBlockState());
                p(lvl, base, x, y, 25, Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z = -24; z <= 24; z++) {
                p(lvl, base, -25, y, z, Blocks.PACKED_ICE.defaultBlockState());
                p(lvl, base, 25, y, z, Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        // Ameias
        for (int x = -25; x <= 25; x += 2) {
            p(lvl, base, x, 9, -25, Blocks.ICE.defaultBlockState());
            p(lvl, base, x, 9, 25, Blocks.ICE.defaultBlockState());
        }
        for (int z = -25; z <= 25; z += 2) {
            p(lvl, base, -25, 9, z, Blocks.ICE.defaultBlockState());
            p(lvl, base, 25, 9, z, Blocks.ICE.defaultBlockState());
        }
        // 8 Torres (4 cantos + 4 meio): 20 blocos altura
        for (int[] tc : new int[][]{{-25,-25},{25,-25},{-25,25},{25,25},{0,-25},{0,25},{-25,0},{25,0}}) {
            buildTorreGlacial(lvl, base, tc[0], tc[1]);
        }
        // Portão principal
        for (int y = 1; y <= 5; y++) for (int px = -3; px <= 3; px++)
            p(lvl, base, px, y, -25, Blocks.AIR.defaultBlockState());
        for (int px = -3; px <= 3; px++)
            p(lvl, base, px, 6, -25, Blocks.BLUE_ICE.defaultBlockState());
        p(lvl, base, -4, 6, -25, Blocks.BLUE_ICE.defaultBlockState());
        p(lvl, base, 4, 6, -25, Blocks.BLUE_ICE.defaultBlockState());
        // Grade de gelo no portão
        for (int y = 1; y <= 5; y++) {
            p(lvl, base, -3, y, -25, Blocks.IRON_BARS.defaultBlockState());
            p(lvl, base, 3, y, -25, Blocks.IRON_BARS.defaultBlockState());
        }
        // Pátio com fonte de gelo
        for (int fx = -2; fx <= 2; fx++) for (int fz = -2; fz <= 2; fz++)
            p(lvl, base, fx, 1, fz, Blocks.ICE.defaultBlockState());
        p(lvl, base, 0, 2, 0, Blocks.BLUE_ICE.defaultBlockState());
        p(lvl, base, 0, 3, 0, Blocks.BEACON.defaultBlockState());
        // Salão do trono 17x17 (fundo norte)
        for (int x = -8; x <= 8; x++) for (int z = 8; z <= 16; z++)
            p(lvl, base, x, 1, z, Blocks.BLUE_ICE.defaultBlockState());
        for (int y = 1; y <= 8; y++) {
            for (int x = -8; x <= 8; x++) {
                p(lvl, base, x, y, 8, Blocks.PACKED_ICE.defaultBlockState());
                p(lvl, base, x, y, 16, Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z = 9; z <= 15; z++) {
                p(lvl, base, -8, y, z, Blocks.PACKED_ICE.defaultBlockState());
                p(lvl, base, 8, y, z, Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        for (int x = -8; x <= 8; x++) for (int z = 8; z <= 16; z++)
            p(lvl, base, x, 9, z, Blocks.ICE.defaultBlockState());
        // Trono de gelo (quest 89 - coroa aqui)
        for (int tx = -1; tx <= 1; tx++) {
            p(lvl, base, tx, 1, 15, Blocks.BLUE_ICE.defaultBlockState());
            p(lvl, base, tx, 2, 15, Blocks.BLUE_ICE.defaultBlockState());
        }
        p(lvl, base, 0, 3, 15, Blocks.BLUE_ICE.defaultBlockState());
        p(lvl, base, 0, 4, 15, Blocks.BEACON.defaultBlockState());
        // Tapete azul até o trono
        for (int tz = 9; tz <= 14; tz++)
            p(lvl, base, 0, 1, tz, Blocks.BLUE_CARPET.defaultBlockState());
        // Baú com Coroa de Nivéria (quest 88)
        p(lvl, base, 2, 1, 15, Blocks.CHEST.defaultBlockState());
        // Salas laterais
        buildSalaArsenal(lvl, base.offset(-18, 1, -10));
        buildSalaArsenal(lvl, base.offset(15, 1, -10));
        // Iluminação
        for (int lx = -22; lx <= 22; lx += 7) {
            p(lvl, base, lx, 8, -24, Blocks.LANTERN.defaultBlockState());
            p(lvl, base, lx, 8, 24, Blocks.LANTERN.defaultBlockState());
        }
        for (int lz = -22; lz <= 22; lz += 7) {
            p(lvl, base, -24, 8, lz, Blocks.LANTERN.defaultBlockState());
            p(lvl, base, 24, 8, lz, Blocks.LANTERN.defaultBlockState());
        }
        // Arena no topo da torre central (quest 98-100)
        buildArena(lvl, base.offset(0, 21, 18));
    }
    private static void buildTorreGlacial(ServerLevel lvl, BlockPos base, int tx, int tz) {
        int sx = tx == 0 ? 1 : (tx < 0 ? -1 : 1);
        int sz = tz == 0 ? 1 : (tz < 0 ? -1 : 1);
        for (int y = 1; y <= 20; y++) {
            for (int dx = 0; dx <= 2; dx++) for (int dz = 0; dz <= 2; dz++) {
                p(lvl, base, tx + dx * sx, y, tz + dz * sz, Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        // Topo cônico de blue ice
        for (int y = 21; y <= 24; y++) p(lvl, base, tx, y, tz, Blocks.BLUE_ICE.defaultBlockState());
        p(lvl, base, tx, 25, tz, Blocks.BEACON.defaultBlockState());
        // Tocha
        p(lvl, base, tx, 3, tz, Blocks.WALL_TORCH.defaultBlockState());
        p(lvl, base, tx, 10, tz, Blocks.WALL_TORCH.defaultBlockState());
    }
    private static void buildSalaArsenal(ServerLevel lvl, BlockPos o) {
        for (int y = 0; y <= 4; y++) {
            for (int x = 0; x < 6; x++) {
                p(lvl, o, x, y, 0, Blocks.PACKED_ICE.defaultBlockState());
                p(lvl, o, x, y, 5, Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z = 1; z < 5; z++) {
                p(lvl, o, 0, y, z, Blocks.PACKED_ICE.defaultBlockState());
                p(lvl, o, 5, y, z, Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        for (int x = 0; x < 6; x++) for (int z = 0; z < 6; z++)
            p(lvl, o, x, 5, z, Blocks.ICE.defaultBlockState());
        p(lvl, o, 2, 0, 0, Blocks.SPRUCE_DOOR.defaultBlockState());
        p(lvl, o, 1, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 2, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 3, 0, 2, Blocks.ANVIL.defaultBlockState());
        p(lvl, o, 4, 0, 2, Blocks.BLAST_FURNACE.defaultBlockState());
        p(lvl, o, 2, 3, 2, Blocks.TORCH.defaultBlockState());
    }
    // Arena final no topo (quest 99-100)
    private static void buildArena(ServerLevel lvl, BlockPos o) {
        // Piso circular de blue ice 15x15
        for (int x = -7; x <= 7; x++) for (int z = -7; z <= 7; z++) {
            if (x * x + z * z <= 49) p(lvl, o, x, 0, z, Blocks.BLUE_ICE.defaultBlockState());
        }
        // Mureta
        for (int x = -7; x <= 7; x++) for (int z = -7; z <= 7; z++) {
            if (x * x + z * z >= 44 && x * x + z * z <= 50) {
                p(lvl, o, x, 1, z, Blocks.PACKED_ICE.defaultBlockState());
                p(lvl, o, x, 2, z, Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        // Beacon central
        p(lvl, o, 0, 1, 0, Blocks.IRON_BLOCK.defaultBlockState());
        p(lvl, o, 0, 2, 0, Blocks.BEACON.defaultBlockState());
        // 4 pilares de blue ice
        for (int[] c : new int[][]{{-5,-5},{5,-5},{-5,5},{5,5}}) {
            for (int py = 1; py <= 5; py++) p(lvl, o, c[0], py, c[1], Blocks.BLUE_ICE.defaultBlockState());
        }
        // Tocha em cada pilar
        for (int[] c : new int[][]{{-5,-5},{5,-5},{-5,5},{5,5}}) {
            p(lvl, o, c[0], 5, c[1], Blocks.LANTERN.defaultBlockState());
        }
    }
}
