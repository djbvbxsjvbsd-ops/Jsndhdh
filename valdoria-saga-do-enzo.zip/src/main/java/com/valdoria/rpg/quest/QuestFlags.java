package com.valdoria.rpg.quest;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.entity.EnzoGlacial;
import com.valdoria.rpg.registry.ModEntities;
import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;
import java.util.Set;
/** Ativa as flags das quests FLAG (chamado 1x/segundo por QuestManager.tick). */
public final class QuestFlags {
    private QuestFlags() {}
    // Posições das estruturas (NiveriaStructures.generateAll)
    private static final double[] VILA = {80, 0}, TEMPLO = {-120, 60}, CASTELO = {0, 200}, ARENA = {0, 218};
    private static final Set<Block> PLACED = Set.of(Blocks.COBBLESTONE, Blocks.STONE_BRICKS, Blocks.OAK_PLANKS,
            Blocks.SPRUCE_PLANKS, Blocks.BRICKS, Blocks.DIRT);
    private static boolean near(ServerPlayer p, double[] c, double r) {
        double dx = p.getX() - c[0], dz = p.getZ() - c[1];
        return dx * dx + dz * dz <= r * r;
    }
    private static void set(ServerPlayer p, String flag, boolean cond) {
        if (cond && !PlayerData.hasFlag(p, flag)) PlayerData.setFlag(p, flag);
    }
    public static void tick(ServerPlayer sp) {
        int done = PlayerData.getCompleted(sp);
        if (done < 49) return;
        boolean niv = sp.level().dimension().equals(NiveriaDimension.NIVERIA);
        set(sp, "portal_niveria_built", QuestManager.count(sp, "valdorianrpg:chave_glacial") >= 1);
        if (!niv) return;
        ServerLevel lvl = sp.serverLevel();
        int secs = PlayerData.root(sp).getInt("niveria_secs") + 1;
        PlayerData.root(sp).putInt("niveria_secs", secs);
        BlockPos spawn = lvl.getSharedSpawnPos();
        double sx = sp.getX() - spawn.getX(), sz = sp.getZ() - spawn.getZ();
        set(sp, "nevasca_survived", secs >= 60);
        set(sp, "aldric_found_niveria", secs >= 90);
        set(sp, "passagem_secreta_found", sp.getY() < 40);
        set(sp, "ice_spikes_explored", sx * sx + sz * sz >= 100.0D * 100.0D);
        set(sp, "vila_nevada_found", near(sp, VILA, 40));
        set(sp, "montanha_nevada_top", sp.getY() >= 110);
        set(sp, "templo_glacial_found", near(sp, TEMPLO, 30));
        set(sp, "livro_templo_found", near(sp, TEMPLO, 12));
        set(sp, "profecia_niveria_read", PlayerData.hasFlag(sp, "livro_templo_found"));
        set(sp, "forja_glacial_built", QuestManager.count(sp, "minecraft:blast_furnace") >= 1);
        set(sp, "rei_gelo_classe_desbloqueada", PlayerData.hasFlag(sp, "guardiao_glacial_dead"));
        set(sp, "cidade_niveria_found", near(sp, CASTELO, 60));
        set(sp, "torre_glacial_built", pillar(sp, 15));
        set(sp, "portal_arena_final_ativado", QuestManager.count(sp, "valdorianrpg:coroa_niveria") >= 1);
        set(sp, "castelo_enzo_glacial_entered", near(sp, CASTELO, 20));
        set(sp, "arena_final_reached", near(sp, ARENA, 8)
                && lvl.getBlockState(sp.blockPosition().below()).is(Blocks.BLUE_ICE));
        spawnBoss(sp, done);
    }
    private static boolean pillar(ServerPlayer sp, int h) {
        ServerLevel l = sp.serverLevel();
        BlockPos p = sp.blockPosition().below();
        int n = 0;
        while (n < h && PLACED.contains(l.getBlockState(p.below(n)).getBlock())) n++;
        return n >= h;
    }
    /** Invoca o chefe da missão atual (uma vez por missão). */
    private static void spawnBoss(ServerPlayer sp, int done) {
        if (done >= QuestData.size()) return;
        Quest q = QuestData.get(done + 1);
        if (q.type() != Quest.Type.FLAG) return;
        EntityType<?> type = switch (q.target()) {
            case "guardiao_glacial_dead", "ultimo_guardiao_dead" -> ModEntities.GUARDIAO_GLACIAL.get();
            case "senhor_gelo_dead" -> ModEntities.SENHOR_GELO.get();
            case "dragao_gelo_dead" -> ModEntities.DRAGAO_GELO.get();
            case "enzo_glacial_dead" -> ModEntities.ENZO_GLACIAL.get();
            default -> null;
        };
        if (type == null) return;
        String key = "boss_spawned_" + q.id();
        if (PlayerData.hasFlag(sp, key)) return;
        PlayerData.setFlag(sp, key);
        ServerLevel lvl = sp.serverLevel();
        if (type == ModEntities.ENZO_GLACIAL.get()) { EnzoGlacial.spawnNear(sp); return; }
        Entity e = type.create(lvl);
        if (e == null) return;
        double x = sp.getX() + 8.0D, z = sp.getZ();
        double y = lvl.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, (int) x, (int) z);
        e.moveTo(x, y, z, 0.0F, 0.0F);
        lvl.addFreshEntity(e);
    }
}
