// [NiveriaChunkGenerator.java] src/main/java/com/valdoria/rpg/world/NiveriaChunkGenerator.java
package com.valdoria.rpg.world;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.valdoria.rpg.registry.ModBiomes;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.biome.FixedBiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.chunk.ChunkGeneratorStructureState;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
public class NiveriaChunkGenerator extends ChunkGenerator {
    public static final Codec<NiveriaChunkGenerator> CODEC = RecordCodecBuilder.create(inst ->
            inst.group(BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.biomeSource))
                    .apply(inst, NiveriaChunkGenerator::new));
    private static final int SEA_LEVEL = 63;
    private static final int BASE_HEIGHT = 60;
    private static final int TERRAIN_AMPLITUDE = 20;
    public NiveriaChunkGenerator(BiomeSource biomeSource) {
        super(biomeSource);
    }
    public static NiveriaChunkGenerator create(HolderLookup.Provider lookup) {
        Holder<Biome> iceBiome = lookup.lookupOrThrow(net.minecraft.core.registries.Registries.BIOME)
                .getOrThrow(net.minecraft.world.level.biome.Biomes.ICE_SPIKES);
        return new NiveriaChunkGenerator(new FixedBiomeSource(iceBiome));
    }
    @Override protected Codec<? extends ChunkGenerator> codec() { return CODEC; }
    @Override
    public void applyCarvers(WorldGenRegion region, long seed, RandomState random,
            BiomeManager bm, StructureManager sm, ChunkAccess chunk, GenerationStep.Carving step) {}
    @Override
    public void buildSurface(WorldGenRegion region, StructureManager sm, RandomState random, ChunkAccess chunk) {
        int cx = chunk.getPos().getMinBlockX();
        int cz = chunk.getPos().getMinBlockZ();
        for (int x = 0; x < 16; x++) {
            for (int z = 0; z < 16; z++) {
                int worldX = cx + x;
                int worldZ = cz + z;
                int height = getTerrainHeight(worldX, worldZ);
                for (int y = -64; y <= height; y++) {
                    BlockState state;
                    if (y < height - 4) state = Blocks.STONE.defaultBlockState();
                    else if (y < height - 1) state = Blocks.PACKED_ICE.defaultBlockState();
                    else if (y == height - 1) state = Blocks.ICE.defaultBlockState();
                    else state = Blocks.SNOW_BLOCK.defaultBlockState();
                    chunk.setBlockState(new BlockPos(worldX, y, worldZ), state, false);
                }
                // Neve por cima
                chunk.setBlockState(new BlockPos(worldX, height + 1, worldZ),
                        Blocks.SNOW.defaultBlockState(), false);
                // Picos de gelo aleatórios
                if (isIceSpike(worldX, worldZ)) {
                    int spikeHeight = 5 + (Math.abs(worldX * 7919 + worldZ * 1013) % 12);
                    for (int sy = 0; sy < spikeHeight; sy++) {
                        chunk.setBlockState(new BlockPos(worldX, height + 1 + sy, worldZ),
                                Blocks.PACKED_ICE.defaultBlockState(), false);
                    }
                }
            }
        }
    }
    private int getTerrainHeight(int x, int z) {
        double n = noise(x * 0.02, z * 0.02) * TERRAIN_AMPLITUDE
                + noise(x * 0.05, z * 0.05) * 8
                + noise(x * 0.1, z * 0.1) * 4;
        return BASE_HEIGHT + (int) n;
    }
    private boolean isIceSpike(int x, int z) {
        long hash = (long) x * 341873128712L + (long) z * 132897987541L;
        return (hash ^ (hash >> 17)) % 20 == 0;
    }
    private double noise(double x, double z) {
        int xi = (int) Math.floor(x);
        int zi = (int) Math.floor(z);
        double fx = x - xi, fz = z - zi;
        double a = grad(xi, zi, fx, fz);
        double b = grad(xi + 1, zi, fx - 1, fz);
        double c = grad(xi, zi + 1, fx, fz - 1);
        double d = grad(xi + 1, zi + 1, fx - 1, fz - 1);
        double u = fx * fx * (3 - 2 * fx);
        double v = fz * fz * (3 - 2 * fz);
        return lerp(lerp(a, b, u), lerp(c, d, u), v);
    }
    private double grad(int x, int z, double dx, double dz) {
        int h = (x * 1664525 + z * 1013904223) & 3;
        return switch (h) {
            case 0 -> dx + dz;
            case 1 -> -dx + dz;
            case 2 -> dx - dz;
            default -> -dx - dz;
        };
    }
    private double lerp(double a, double b, double t) { return a + t * (b - a); }
    @Override
    public void spawnOriginalMobs(WorldGenRegion region) {}
    @Override
    public int getGenDepth() { return 384; }
    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor exec, Blender blender,
            RandomState random, StructureManager sm, ChunkAccess chunk) {
        return CompletableFuture.completedFuture(chunk);
    }
    @Override
    public int getSeaLevel() { return SEA_LEVEL; }
    @Override
    public int getMinY() { return -64; }
    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types type, LevelHeightAccessor level, RandomState random) {
        return getTerrainHeight(x, z) + 1;
    }
    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor level, RandomState random) {
        int h = getTerrainHeight(x, z);
        BlockState[] states = new BlockState[h + 65];
        for (int y = 0; y <= h; y++) states[y + 64] = Blocks.PACKED_ICE.defaultBlockState();
        return new NoiseColumn(-64, states);
    }
    @Override
    public void addDebugScreenInfo(List<String> info, RandomState random, BlockPos pos) {}
    @Override
    public void applyBiomeDecoration(WorldGenLevel region, ChunkAccess chunk, StructureManager sm) {
        placeIceTrees(region, chunk);
    }
    private void placeIceTrees(WorldGenLevel region, ChunkAccess chunk) {
        int cx = chunk.getPos().getMinBlockX();
        int cz = chunk.getPos().getMinBlockZ();
        java.util.Random rng = new java.util.Random(cx * 341873128712L ^ cz * 132897987541L);
        int trees = rng.nextInt(4);
        for (int i = 0; i < trees; i++) {
            int x = cx + rng.nextInt(16);
            int z = cz + rng.nextInt(16);
            int y = getTerrainHeight(x, z) + 2;
            // Tronco de pinheiro (spruce)
            for (int ty = 0; ty < 5; ty++) {
                try { region.setBlock(new BlockPos(x, y + ty, z), Blocks.SPRUCE_LOG.defaultBlockState(), 3); } catch (Exception ignored) {}
            }
            // Folhas
            for (int lx = -2; lx <= 2; lx++) for (int lz = -2; lz <= 2; lz++) {
                if (Math.abs(lx) == 2 && Math.abs(lz) == 2) continue;
                try { region.setBlock(new BlockPos(x + lx, y + 3, z + lz), Blocks.SPRUCE_LEAVES.defaultBlockState(), 3); } catch (Exception ignored) {}
                try { region.setBlock(new BlockPos(x + lx, y + 4, z + lz), Blocks.SPRUCE_LEAVES.defaultBlockState(), 3); } catch (Exception ignored) {}
            }
            for (int lx = -1; lx <= 1; lx++) for (int lz = -1; lz <= 1; lz++) {
                try { region.setBlock(new BlockPos(x + lx, y + 5, z + lz), Blocks.SPRUCE_LEAVES.defaultBlockState(), 3); } catch (Exception ignored) {}
            }
            try { region.setBlock(new BlockPos(x, y + 6, z), Blocks.SPRUCE_LEAVES.defaultBlockState(), 3); } catch (Exception ignored) {}
        }
    }
    @Override
    public void createStructures(RegistryAccess access, ChunkGeneratorStructureState state,
            StructureManager sm, ChunkAccess chunk, StructureTemplateManager stm) {}
    @Override
    public void createReferences(WorldGenLevel region, StructureManager sm, ChunkAccess chunk) {}
}
