// [NiveriaDimension.java]
package com.valdoria.rpg.world;
import com.valdoria.rpg.ValdoriaMod;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
public final class NiveriaDimension {
    public static final ResourceKey<Level> NIVERIA = ResourceKey.create(
            net.minecraft.core.registries.Registries.DIMENSION,
            new ResourceLocation(ValdoriaMod.MODID, "niveria"));
    private NiveriaDimension() {}
}
