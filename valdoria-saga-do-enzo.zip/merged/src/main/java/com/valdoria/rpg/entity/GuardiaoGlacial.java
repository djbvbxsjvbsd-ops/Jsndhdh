// [GuardiaoGlacial.java]
package com.valdoria.rpg.entity;
import com.valdoria.rpg.data.PlayerData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.animal.IronGolem;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
public class GuardiaoGlacial extends IronGolem {
    // Sem ServerBossEvent e sem setCustomName: o nome vem só de entity.valdorianrpg.guardiao_glacial (lang).
    public GuardiaoGlacial(EntityType<? extends GuardiaoGlacial> type, Level level) {
        super(type, level);
        this.setPersistenceRequired();
    }
    public static AttributeSupplier.Builder createAttributes() {
        return IronGolem.createAttributes()
                .add(Attributes.MAX_HEALTH, 150.0D)
                .add(Attributes.ATTACK_DAMAGE, 10.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.22D);
    }
    @Override
    public void die(DamageSource src) {
        super.die(src);
        if (src.getEntity() instanceof ServerPlayer sp) {
            PlayerData.setFlag(sp, "guardiao_glacial_dead");
            if (PlayerData.getCompleted(sp) >= 97) PlayerData.setFlag(sp, "ultimo_guardiao_dead");
        }
    }
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        if (tickCount % 40 == 0) {
            for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(5.0D))) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 1));
            }
        }
    }
}
