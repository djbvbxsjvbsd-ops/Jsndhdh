package com.valdoria.rpg.block;
import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
public class PortalNiveriaBlock extends Block {
    public PortalNiveriaBlock(Properties props) { super(props); }
    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(entity instanceof ServerPlayer sp)) return;
        if (sp.isOnPortalCooldown()) { sp.setPortalCooldown(); return; }
        ServerLevel target = sp.getServer().getLevel(NiveriaDimension.NIVERIA);
        if (target == null) return;
        BlockPos s = target.getSharedSpawnPos();
        int y = target.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, s.getX(), s.getZ()) + 1;
        sp.teleportTo(target, s.getX() + 0.5D, y, s.getZ() + 0.5D, sp.getYRot(), sp.getXRot());
        sp.setPortalCooldown();
    }
}
