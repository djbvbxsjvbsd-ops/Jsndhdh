package com.valdoria.rpg.registry;

public final class ModCodecs {
    private ModCodecs() {}
}
