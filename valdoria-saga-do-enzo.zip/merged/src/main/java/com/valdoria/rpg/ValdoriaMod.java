package com.valdoria.rpg;

import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.registry.ModBlocks;
import com.valdoria.rpg.registry.ModEntities;
import com.valdoria.rpg.registry.ModItems;
import com.valdoria.rpg.registry.ModTabs;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(ValdoriaMod.MODID)
public class ValdoriaMod {

    public static final String MODID = "valdorianrpg";

    public ValdoriaMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(bus);
        ModItems.ITEMS.register(bus);
        ModEntities.ENTITIES.register(bus);
        ModTabs.TABS.register(bus);
        bus.addListener(this::commonSetup);
    }

    private void commonSetup(FMLCommonSetupEvent e) {
        e.enqueueWork(ModNetwork::register);
    }
}
