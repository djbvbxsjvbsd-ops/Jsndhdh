// [NiveriaStructures.java] — Estruturas dentro da sala gigante de neve de Nivéria
package com.valdoria.rpg.world;

import com.valdoria.rpg.data.PlayerData;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Gera as estruturas de Nivéria DENTRO da sala fechada gigante.
 * O spawn de Nivéria é em (0, 15, 0) (piso da sala em Y=15).
 * A sala tem 1024x1024 de área interna — as estruturas ficam espalhadas nesse espaço.
 * 
 * Layout (relativo ao spawn 0,0):
 *   Vila Nevada      → (+80, 0)
 *   Templo Glacial   → (-120, +60)
 *   Castelo Nivéria  → (0, +200)
 *   Arena Final      → (0, +218) [topo do castelo]
 */
public final class NiveriaStructures {
    private NiveriaStructures() {}

    // Y do piso da sala (NiveriaChunkGenerator.PISO_Y + 4 snow + 1)
    private static final int PISO = 20;

    public static void generateAll(ServerLevel level, BlockPos playerPos) {
        // Usa (0,0) como centro de referência de Nivéria
        BlockPos centro = new BlockPos(0, PISO, 0);
        buildVilanevada(level,    centro.offset(80,  0, 0));
        buildTemploGlacial(level, centro.offset(-120, 0, 60));
        buildCasteloNiveria(level,centro.offset(0,   0, 200));
    }

    private static void p(ServerLevel lvl, BlockPos o, int dx, int dy, int dz, BlockState b) {
        lvl.setBlock(o.offset(dx, dy, dz), b, 3);
    }

    private static void fill(ServerLevel lvl, BlockPos o, int x1, int y1, int z1,
                             int x2, int y2, int z2, BlockState b) {
        for (int x=x1; x<=x2; x++) for (int y=y1; y<=y2; y++) for (int z=z1; z<=z2; z++)
            p(lvl, o, x, y, z, b);
    }

    // ===== VILA NEVADA =====
    public static void buildVilanevada(ServerLevel lvl, BlockPos o) {
        // Praça de neve
        fill(lvl, o, -12, 0, -12, 12, 0, 12, Blocks.SNOW_BLOCK.defaultBlockState());
        // Poço central
        buildPoço(lvl, o.offset(0, 1, 0));
        // 5 casas
        buildCasaNeve(lvl, o.offset(-8, 1, -8));
        buildCasaNeve(lvl, o.offset(6,  1, -8));
        buildCasaNeve(lvl, o.offset(-9, 1,  4));
        buildCasaNeve(lvl, o.offset(6,  1,  4));
        buildCasaForjador(lvl, o.offset(-1, 1,  8));
        // Tochas/lanternas
        for (int[] t : new int[][]{{-12,0},{12,0},{0,-12},{0,12},{-8,8},{8,8}})
            p(lvl, o, t[0], 2, t[1], Blocks.LANTERN.defaultBlockState());
        // Marcador azul no centro (visível de longe)
        p(lvl, o, 0, 4, 0, Blocks.BLUE_ICE.defaultBlockState());
        p(lvl, o, 0, 5, 0, Blocks.SEA_LANTERN.defaultBlockState());
    }

    private static void buildCasaNeve(ServerLevel lvl, BlockPos o) {
        for (int y=0; y<3; y++) {
            for (int x=0; x<5; x++) {
                p(lvl, o, x, y, 0, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, x, y, 4, Blocks.SNOW_BLOCK.defaultBlockState());
            }
            for (int z=1; z<4; z++) {
                p(lvl, o, 0, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, 4, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
            }
        }
        for (int x=0; x<5; x++) for (int z=0; z<5; z++)
            p(lvl, o, x, 3, z, Blocks.SPRUCE_PLANKS.defaultBlockState());
        p(lvl, o, 2, 0, 0, Blocks.SPRUCE_DOOR.defaultBlockState());
        p(lvl, o, 1, 1, 0, Blocks.GLASS_PANE.defaultBlockState());
        p(lvl, o, 3, 1, 0, Blocks.GLASS_PANE.defaultBlockState());
        p(lvl, o, 1, 0, 2, Blocks.RED_BED.defaultBlockState());
        p(lvl, o, 3, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 2, 2, 2, Blocks.TORCH.defaultBlockState());
    }

    private static void buildCasaForjador(ServerLevel lvl, BlockPos o) {
        for (int y=0; y<4; y++) {
            for (int x=0; x<7; x++) {
                p(lvl, o, x, y, 0, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, x, y, 4, Blocks.SNOW_BLOCK.defaultBlockState());
            }
            for (int z=1; z<4; z++) {
                p(lvl, o, 0, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
                p(lvl, o, 6, y, z, Blocks.SNOW_BLOCK.defaultBlockState());
            }
        }
        for (int x=0; x<7; x++) for (int z=0; z<5; z++)
            p(lvl, o, x, 4, z, Blocks.SPRUCE_PLANKS.defaultBlockState());
        p(lvl, o, 3, 0, 0, Blocks.SPRUCE_DOOR.defaultBlockState());
        p(lvl, o, 1, 0, 2, Blocks.FURNACE.defaultBlockState());
        p(lvl, o, 2, 0, 2, Blocks.BLAST_FURNACE.defaultBlockState());
        p(lvl, o, 3, 0, 2, Blocks.ANVIL.defaultBlockState());
        p(lvl, o, 4, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 5, 0, 2, Blocks.CHEST.defaultBlockState());
        p(lvl, o, 3, 3, 2, Blocks.TORCH.defaultBlockState());
    }

    private static void buildPoço(ServerLevel lvl, BlockPos o) {
        for (int x=-1; x<=1; x++) for (int z=-1; z<=1; z++) {
            if (x==0&&z==0) { p(lvl,o,0,0,0,Blocks.WATER.defaultBlockState()); continue; }
            p(lvl,o,x,0,z,Blocks.STONE_BRICKS.defaultBlockState());
            p(lvl,o,x,1,z,Blocks.STONE_BRICKS.defaultBlockState());
        }
        p(lvl,o,-1,2,0,Blocks.SPRUCE_FENCE.defaultBlockState());
        p(lvl,o, 1,2,0,Blocks.SPRUCE_FENCE.defaultBlockState());
        p(lvl,o, 0,3,0,Blocks.OAK_SLAB.defaultBlockState());
    }

    // ===== TEMPLO GLACIAL =====
    public static void buildTemploGlacial(ServerLevel lvl, BlockPos o) {
        // Fundação blue ice
        fill(lvl,o,-10,0,-10,10,0,10,Blocks.BLUE_ICE.defaultBlockState());
        // Paredes 6 blocos
        for (int y=1; y<=6; y++) {
            for (int x=-10; x<=10; x++) {
                p(lvl,o,x,y,-10,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,y, 10,Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z=-9; z<=9; z++) {
                p(lvl,o,-10,y,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o, 10,y,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        // Teto (fechado — agora a sala já tem teto, mas o templo tem o seu próprio)
        fill(lvl,o,-10,7,-10,10,7,10,Blocks.ICE.defaultBlockState());
        // Portão
        for (int y=1; y<=4; y++) for (int x=-2; x<=2; x++)
            p(lvl,o,x,y,-10,Blocks.AIR.defaultBlockState());
        // 4 cristais guardiões (quest 74)
        for (int[] c : new int[][]{{-5,5},{5,5},{-5,-5},{5,-5}}) {
            for (int cy=1; cy<=3; cy++) p(lvl,o,c[0],cy,c[1],Blocks.BLUE_ICE.defaultBlockState());
            p(lvl,o,c[0],4,c[1],Blocks.BEACON.defaultBlockState());
        }
        // Altar central
        p(lvl,o,0,1,0,Blocks.CHISELED_STONE_BRICKS.defaultBlockState());
        p(lvl,o,0,2,0,Blocks.ENCHANTING_TABLE.defaultBlockState());
        // Biblioteca (quest 76)
        for (int bx=-8; bx<=-5; bx++) {
            p(lvl,o,bx,1,7,Blocks.BOOKSHELF.defaultBlockState());
            p(lvl,o,bx,2,7,Blocks.BOOKSHELF.defaultBlockState());
        }
        p(lvl,o,-6,1,6,Blocks.CHEST.defaultBlockState());
        // Torres dos cantos
        for (int[] c : new int[][]{{-10,-10},{10,-10},{-10,10},{10,10}}) {
            for (int ty=7; ty<=12; ty++) p(lvl,o,c[0],ty,c[1],Blocks.PACKED_ICE.defaultBlockState());
            p(lvl,o,c[0],13,c[1],Blocks.BLUE_ICE.defaultBlockState());
        }
        // Forja Glacial (quest 79)
        p(lvl,o,7,1,-7,Blocks.BLAST_FURNACE.defaultBlockState());
        p(lvl,o,8,1,-7,Blocks.ANVIL.defaultBlockState());
        p(lvl,o,7,1,-8,Blocks.BLUE_ICE.defaultBlockState());
        p(lvl,o,8,1,-8,Blocks.CHEST.defaultBlockState());
        // Lanternas
        for (int[] t : new int[][]{{-9,0},{9,0},{0,-9},{0,9},{-7,-7},{7,-7},{-7,7},{7,7}})
            p(lvl,o,t[0],3,t[1],Blocks.LANTERN.defaultBlockState());
    }

    // ===== CASTELO DE NIVÉRIA =====
    public static void buildCasteloNiveria(ServerLevel lvl, BlockPos o) {
        // Fosso de gelo
        for (int x=-27; x<=27; x++) for (int z=-27; z<=27; z++)
            if (Math.abs(x)>=24||Math.abs(z)>=24) {
                p(lvl,o,x,-1,z,Blocks.BLUE_ICE.defaultBlockState());
                p(lvl,o,x,-2,z,Blocks.BLUE_ICE.defaultBlockState());
            }
        // Fundação
        fill(lvl,o,-25,0,-25,25,0,25,Blocks.BLUE_ICE.defaultBlockState());
        // Muralhas externas 8 blocos
        for (int y=1; y<=8; y++) {
            for (int x=-25; x<=25; x++) {
                p(lvl,o,x,y,-25,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,y, 25,Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z=-24; z<=24; z++) {
                p(lvl,o,-25,y,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o, 25,y,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        // Ameias
        for (int x=-25; x<=25; x+=2) {
            p(lvl,o,x,9,-25,Blocks.ICE.defaultBlockState());
            p(lvl,o,x,9, 25,Blocks.ICE.defaultBlockState());
        }
        for (int z=-25; z<=25; z+=2) {
            p(lvl,o,-25,9,z,Blocks.ICE.defaultBlockState());
            p(lvl,o, 25,9,z,Blocks.ICE.defaultBlockState());
        }
        // 8 Torres glaciais
        for (int[] tc : new int[][]{{-25,-25},{25,-25},{-25,25},{25,25},{0,-25},{0,25},{-25,0},{25,0}})
            buildTorreGlacial(lvl, o, tc[0], tc[1]);
        // Portão
        for (int y=1; y<=5; y++) for (int px=-3; px<=3; px++)
            p(lvl,o,px,y,-25,Blocks.AIR.defaultBlockState());
        for (int px=-3; px<=3; px++) p(lvl,o,px,6,-25,Blocks.BLUE_ICE.defaultBlockState());
        // Grades
        for (int y=1; y<=5; y++) {
            p(lvl,o,-3,y,-25,Blocks.IRON_BARS.defaultBlockState());
            p(lvl,o, 3,y,-25,Blocks.IRON_BARS.defaultBlockState());
        }
        // Pátio com fonte
        fill(lvl,o,-2,1,-2,2,1,2,Blocks.ICE.defaultBlockState());
        p(lvl,o,0,2,0,Blocks.BLUE_ICE.defaultBlockState());
        p(lvl,o,0,3,0,Blocks.BEACON.defaultBlockState());
        // Salão do trono
        fill(lvl,o,-8,1,8,8,1,16,Blocks.BLUE_ICE.defaultBlockState());
        for (int y=1; y<=8; y++) {
            for (int x=-8; x<=8; x++) {
                p(lvl,o,x,y, 8,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,y,16,Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z=9; z<=15; z++) {
                p(lvl,o,-8,y,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o, 8,y,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        fill(lvl,o,-8,9,8,8,9,16,Blocks.ICE.defaultBlockState());
        // Trono de gelo
        for (int tx=-1; tx<=1; tx++) {
            p(lvl,o,tx,1,15,Blocks.BLUE_ICE.defaultBlockState());
            p(lvl,o,tx,2,15,Blocks.BLUE_ICE.defaultBlockState());
        }
        p(lvl,o,0,3,15,Blocks.BLUE_ICE.defaultBlockState());
        p(lvl,o,0,4,15,Blocks.BEACON.defaultBlockState());
        // Tapete azul
        for (int tz=9; tz<=14; tz++) p(lvl,o,0,1,tz,Blocks.BLUE_CARPET.defaultBlockState());
        // Baú da coroa (quest 88)
        p(lvl,o,2,1,15,Blocks.CHEST.defaultBlockState());
        // Salas laterais
        buildSalaArsenal(lvl, o.offset(-18, 1, -10));
        buildSalaArsenal(lvl, o.offset( 15, 1, -10));
        // Iluminação
        for (int lx=-22; lx<=22; lx+=7) {
            p(lvl,o,lx,8,-24,Blocks.LANTERN.defaultBlockState());
            p(lvl,o,lx,8, 24,Blocks.LANTERN.defaultBlockState());
        }
        for (int lz=-22; lz<=22; lz+=7) {
            p(lvl,o,-24,8,lz,Blocks.LANTERN.defaultBlockState());
            p(lvl,o, 24,8,lz,Blocks.LANTERN.defaultBlockState());
        }
        // Arena no topo (quest 98-100)
        buildArena(lvl, o.offset(0, 21, 18));
    }

    private static void buildTorreGlacial(ServerLevel lvl, BlockPos base, int tx, int tz) {
        int sx = tx<0?-1:1, sz = tz<0?-1:1;
        for (int y=1; y<=20; y++)
            for (int dx=0; dx<=2; dx++) for (int dz=0; dz<=2; dz++)
                p(lvl,base,tx+dx*sx,y,tz+dz*sz,Blocks.PACKED_ICE.defaultBlockState());
        for (int y=21; y<=24; y++) p(lvl,base,tx,y,tz,Blocks.BLUE_ICE.defaultBlockState());
        p(lvl,base,tx,25,tz,Blocks.BEACON.defaultBlockState());
        p(lvl,base,tx, 3,tz,Blocks.WALL_TORCH.defaultBlockState());
        p(lvl,base,tx,10,tz,Blocks.WALL_TORCH.defaultBlockState());
    }

    private static void buildSalaArsenal(ServerLevel lvl, BlockPos o) {
        for (int y=0; y<=4; y++) {
            for (int x=0; x<6; x++) {
                p(lvl,o,x,y,0,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,y,5,Blocks.PACKED_ICE.defaultBlockState());
            }
            for (int z=1; z<5; z++) {
                p(lvl,o,0,y,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,5,y,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        }
        fill(lvl,o,0,5,0,5,5,5,Blocks.ICE.defaultBlockState());
        p(lvl,o,2,0,0,Blocks.SPRUCE_DOOR.defaultBlockState());
        p(lvl,o,1,0,2,Blocks.CHEST.defaultBlockState());
        p(lvl,o,2,0,2,Blocks.CHEST.defaultBlockState());
        p(lvl,o,3,0,2,Blocks.ANVIL.defaultBlockState());
        p(lvl,o,4,0,2,Blocks.BLAST_FURNACE.defaultBlockState());
        p(lvl,o,2,3,2,Blocks.TORCH.defaultBlockState());
    }

    private static void buildArena(ServerLevel lvl, BlockPos o) {
        // Piso circular de blue ice 15x15
        for (int x=-7; x<=7; x++) for (int z=-7; z<=7; z++)
            if (x*x+z*z<=49) p(lvl,o,x,0,z,Blocks.BLUE_ICE.defaultBlockState());
        // Mureta
        for (int x=-7; x<=7; x++) for (int z=-7; z<=7; z++)
            if (x*x+z*z>=44&&x*x+z*z<=50) {
                p(lvl,o,x,1,z,Blocks.PACKED_ICE.defaultBlockState());
                p(lvl,o,x,2,z,Blocks.PACKED_ICE.defaultBlockState());
            }
        p(lvl,o,0,1,0,Blocks.IRON_BLOCK.defaultBlockState());
        p(lvl,o,0,2,0,Blocks.BEACON.defaultBlockState());
        for (int[] c : new int[][]{{-5,-5},{5,-5},{-5,5},{5,5}}) {
            for (int py=1; py<=5; py++) p(lvl,o,c[0],py,c[1],Blocks.BLUE_ICE.defaultBlockState());
            p(lvl,o,c[0],5,c[1],Blocks.LANTERN.defaultBlockState());
        }
    }
}
