// [NiveriaChunkGenerator.java] — Nivéria: sala gigante e fechada de neve (não dimensão aberta)
package com.valdoria.rpg.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.biome.FixedBiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.chunk.ChunkGeneratorStructureState;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Nivéria: em vez de um bioma aberto, gera uma SALA GIGANTE E FECHADA de neve/gelo.
 * O chão é de gelo empacotado, as paredes e teto são de neve compacta, criando um
 * ambiente claustrofóbico e eterno. O tamanho é ENORME — a "sala" se expande
 * chunk a chunk mas as paredes sempre se fecham ao redor, formando uma caverna
 * de gelo gigante sem céu visível.
 */
public class NiveriaChunkGenerator extends ChunkGenerator {

    public static final Codec<NiveriaChunkGenerator> CODEC = RecordCodecBuilder.create(inst ->
            inst.group(BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.biomeSource))
                    .apply(inst, NiveriaChunkGenerator::new));

    // Sala de 512 blocos de raio ao redor da origem (1024x1024 de espaço interno)
    private static final int SALA_RAIO    = 512;
    // Altura interna da sala (do piso ao teto)
    private static final int SALA_ALTURA  = 60;
    // Y do piso
    private static final int PISO_Y       = 10;
    // Y do teto
    private static final int TETO_Y       = PISO_Y + SALA_ALTURA;
    // Espessura das paredes
    private static final int PAREDE_ESP   = 5;

    public NiveriaChunkGenerator(BiomeSource biomeSource) { super(biomeSource); }

    public static NiveriaChunkGenerator create(HolderLookup.Provider lookup) {
        Holder<Biome> iceBiome = lookup.lookupOrThrow(net.minecraft.core.registries.Registries.BIOME)
                .getOrThrow(net.minecraft.world.level.biome.Biomes.ICE_SPIKES);
        return new NiveriaChunkGenerator(new FixedBiomeSource(iceBiome));
    }

    @Override protected Codec<? extends ChunkGenerator> codec() { return CODEC; }

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager sm, RandomState random, ChunkAccess chunk) {
        int cx = chunk.getPos().getMinBlockX();
        int cz = chunk.getPos().getMinBlockZ();

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int wx = cx + lx;
                int wz = cz + lz;

                boolean dentroX = Math.abs(wx) < SALA_RAIO;
                boolean dentroZ = Math.abs(wz) < SALA_RAIO;
                boolean dentro  = dentroX && dentroZ;

                if (dentro) {
                    // === INTERIOR DA SALA ===

                    // Piso: camadas de pedra → gelo empacotado → gelo → neve
                    for (int y = 0; y < PISO_Y; y++)
                        setBlock(chunk, wx, y, wz, Blocks.STONE.defaultBlockState());
                    for (int y = PISO_Y; y < PISO_Y + 3; y++)
                        setBlock(chunk, wx, y, wz, Blocks.PACKED_ICE.defaultBlockState());
                    setBlock(chunk, wx, PISO_Y + 3, wz, Blocks.ICE.defaultBlockState());
                    setBlock(chunk, wx, PISO_Y + 4, wz, Blocks.SNOW_BLOCK.defaultBlockState());

                    // Interior vazio (ar) entre piso e teto
                    for (int y = PISO_Y + 5; y < TETO_Y; y++)
                        setBlock(chunk, wx, y, wz, Blocks.AIR.defaultBlockState());

                    // Teto: neve compacta 3 camadas
                    for (int y = TETO_Y; y <= TETO_Y + PAREDE_ESP; y++)
                        setBlock(chunk, wx, y, wz, Blocks.SNOW_BLOCK.defaultBlockState());

                    // Paredes nas bordas da sala (criando o efeito de "fechado")
                    boolean bordaX = Math.abs(wx) >= SALA_RAIO - PAREDE_ESP;
                    boolean bordaZ = Math.abs(wz) >= SALA_RAIO - PAREDE_ESP;
                    if (bordaX || bordaZ) {
                        for (int y = PISO_Y; y <= TETO_Y + PAREDE_ESP; y++)
                            setBlock(chunk, wx, y, wz, Blocks.PACKED_ICE.defaultBlockState());
                    }

                    // Picos de gelo internos (decoração)
                    if (isIceSpike(wx, wz) && !bordaX && !bordaZ) {
                        int spikeH = 3 + (Math.abs(wx * 7919 + wz * 1013) % 8);
                        for (int sy = 0; sy < spikeH; sy++)
                            setBlock(chunk, wx, PISO_Y + 5 + sy, wz, Blocks.PACKED_ICE.defaultBlockState());
                    }

                    // Stalactites de gelo no teto (inverso)
                    if (isStalactite(wx, wz) && !bordaX && !bordaZ) {
                        int stH = 2 + (Math.abs(wx * 1009 + wz * 7727) % 6);
                        for (int sy = 0; sy < stH; sy++)
                            setBlock(chunk, wx, TETO_Y - 1 - sy, wz, Blocks.BLUE_ICE.defaultBlockState());
                    }

                    // Gelo azul aleatório no chão (brilho)
                    if (isBlueIcePatch(wx, wz))
                        setBlock(chunk, wx, PISO_Y + 4, wz, Blocks.BLUE_ICE.defaultBlockState());

                } else {
                    // === FORA DA SALA: sólido de neve/pedra (sem void) ===
                    for (int y = 0; y <= TETO_Y + PAREDE_ESP + 5; y++)
                        setBlock(chunk, wx, y, wz,
                                y < PISO_Y ? Blocks.STONE.defaultBlockState() : Blocks.SNOW_BLOCK.defaultBlockState());
                }
            }
        }
    }

    private void setBlock(ChunkAccess chunk, int wx, int y, int wz, BlockState state) {
        if (y < -64 || y > 319) return;
        chunk.setBlockState(new BlockPos(wx, y, wz), state, false);
    }

    private boolean isIceSpike(int x, int z) {
        long h = (long)x * 341873128712L + (long)z * 132897987541L;
        return (h ^ (h >> 17)) % 18 == 0;
    }

    private boolean isStalactite(int x, int z) {
        long h = (long)x * 987654321L + (long)z * 123456789L;
        return (h ^ (h >> 13)) % 22 == 0;
    }

    private boolean isBlueIcePatch(int x, int z) {
        long h = (long)x * 1664525L + (long)z * 1013904223L;
        return (h ^ (h >> 9)) % 30 == 0;
    }

    @Override
    public void applyCarvers(WorldGenRegion r, long seed, RandomState rng, BiomeManager bm,
            StructureManager sm, ChunkAccess chunk, GenerationStep.Carving step) {}

    @Override public void spawnOriginalMobs(WorldGenRegion r) {}
    @Override public int getGenDepth() { return 384; }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor ex, Blender bl,
            RandomState rng, StructureManager sm, ChunkAccess chunk) {
        return CompletableFuture.completedFuture(chunk);
    }

    @Override public int getSeaLevel() { return PISO_Y; }
    @Override public int getMinY() { return -64; }

    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types t, LevelHeightAccessor lvl, RandomState rng) {
        return PISO_Y + 5;
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor lvl, RandomState rng) {
        BlockState[] states = new BlockState[PISO_Y + 6 + 64];
        for (int y = 0; y <= PISO_Y + 5; y++) states[y + 64] = Blocks.PACKED_ICE.defaultBlockState();
        return new NoiseColumn(-64, states);
    }

    @Override public void addDebugScreenInfo(List<String> info, RandomState rng, BlockPos pos) {}

    @Override
    public void applyBiomeDecoration(WorldGenLevel region, ChunkAccess chunk, StructureManager sm) {}

    @Override
    public void createStructures(RegistryAccess access, ChunkGeneratorStructureState state,
            StructureManager sm, ChunkAccess chunk, StructureTemplateManager stm) {}

    @Override
    public void createReferences(WorldGenLevel region, StructureManager sm, ChunkAccess chunk) {}
}
