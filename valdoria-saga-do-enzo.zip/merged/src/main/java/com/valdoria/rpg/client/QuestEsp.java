// [QuestEsp.java] — ESP colorido do alvo da quest atual
package com.valdoria.rpg.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Renderiza bounding-box colorida ao redor do alvo da quest ativa.
 *
 * Chamado a partir de ClientEvents.renderLevel (RenderLevelStageEvent).
 */
public final class QuestEsp {

    private QuestEsp() {}

    /** Cor RGB por ato (igual ao sistema de highlight do servidor). */
    public static int[] actColor(int questId) {
        if (questId <= 10)  return new int[]{255, 215, 0};    // dourado
        if (questId <= 20)  return new int[]{255, 200, 50};   // amarelo
        if (questId <= 30)  return new int[]{255, 60,  60};   // vermelho
        if (questId <= 40)  return new int[]{255, 80,  255};  // magenta
        if (questId <= 50)  return new int[]{255, 255, 255};  // branco
        if (questId <= 60)  return new int[]{0,   220, 255};  // ciano
        if (questId <= 70)  return new int[]{50,  220, 50};   // verde
        if (questId <= 80)  return new int[]{60,  120, 255};  // azul
        if (questId <= 90)  return new int[]{180, 0,   255};  // roxo
        return new int[]{180, 0, 0};                           // vermelho escuro
    }

    /**
     * Renderiza ESP para o alvo atual da quest.
     * @param poseStack PoseStack já transladado para câmera (partialTick)
     * @param bufferSource buffer da cena
     */
    public static void render(PoseStack poseStack, MultiBufferSource.BufferAccess bufferSource) {
        int type    = ClientData.questTargetType;
        String tgt  = ClientData.questTarget;
        int qId     = ClientData.questId;

        if (type == 0 || tgt == null || tgt.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        int[] rgb = actColor(qId);
        float r = rgb[0] / 255f, g = rgb[1] / 255f, b = rgb[2] / 255f;

        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();

        if (type == 1) {
            // KILL — destaca entidades cujo tipo bate com o alvo
            ResourceLocation rl;
            try { rl = new ResourceLocation(tgt); } catch (Exception ex) { return; }

            List<Entity> entities = mc.level.entitiesForRendering().stream()
                    .filter(en -> BuiltInRegistries.ENTITY_TYPE.getKey(en.getType()).equals(rl))
                    .toList();

            for (Entity en : entities) {
                double dx = en.getX() - cam.x;
                double dy = en.getY() - cam.y;
                double dz = en.getZ() - cam.z;
                if (dx * dx + dy * dy + dz * dz > 128 * 128) continue; // máx 128 blocos

                AABB bb = en.getBoundingBox().move(-cam.x, -cam.y, -cam.z);
                drawBox(poseStack, bufferSource, bb, r, g, b, 0.95f);
            }

        } else if (type == 2) {
            // HAVE — destaca ItemEntity no chão cujo item bate
            ResourceLocation rl;
            try { rl = new ResourceLocation(tgt); } catch (Exception ex) { return; }
            Item wantedItem;
            try { wantedItem = BuiltInRegistries.ITEM.get(rl); } catch (Exception ex) { return; }

            List<ItemEntity> items = mc.level.getEntitiesOfClass(ItemEntity.class,
                    mc.player.getBoundingBox().inflate(64));

            for (ItemEntity ie : items) {
                ItemStack stack = ie.getItem();
                if (stack.isEmpty() || !stack.is(wantedItem)) continue;

                double dx = ie.getX() - cam.x;
                double dy = ie.getY() - cam.y;
                double dz = ie.getZ() - cam.z;
                if (dx * dx + dy * dy + dz * dz > 64 * 64) continue;

                AABB bb = ie.getBoundingBox().move(-cam.x, -cam.y, -cam.z);
                // Expande um pouco para itens pequenos ficarem visíveis
                bb = bb.inflate(0.15);
                drawBox(poseStack, bufferSource, bb, r, g, b, 0.95f);
            }
        }
        // Tipo 3 (FLAG/DIM/FACTION) — sem ESP visual, apenas o highlight de chat já ajuda
    }

    // -------------------------------------------------------------------------
    // Desenha uma bounding-box colorida sem profundidade (visível através de blocos)
    // -------------------------------------------------------------------------
    private static void drawBox(PoseStack ps, MultiBufferSource.BufferAccess buf,
                                AABB bb, float r, float g, float b, float alpha) {
        VertexConsumer vc = buf.getBuffer(RenderType.lines());
        Matrix4f mat = ps.last().pose();

        float x0 = (float) bb.minX, y0 = (float) bb.minY, z0 = (float) bb.minZ;
        float x1 = (float) bb.maxX, y1 = (float) bb.maxY, z1 = (float) bb.maxZ;

        // 12 arestas do cubo
        // Fundo
        line(vc, mat, x0,y0,z0, x1,y0,z0, r,g,b,alpha);
        line(vc, mat, x1,y0,z0, x1,y0,z1, r,g,b,alpha);
        line(vc, mat, x1,y0,z1, x0,y0,z1, r,g,b,alpha);
        line(vc, mat, x0,y0,z1, x0,y0,z0, r,g,b,alpha);
        // Topo
        line(vc, mat, x0,y1,z0, x1,y1,z0, r,g,b,alpha);
        line(vc, mat, x1,y1,z0, x1,y1,z1, r,g,b,alpha);
        line(vc, mat, x1,y1,z1, x0,y1,z1, r,g,b,alpha);
        line(vc, mat, x0,y1,z1, x0,y1,z0, r,g,b,alpha);
        // Laterais
        line(vc, mat, x0,y0,z0, x0,y1,z0, r,g,b,alpha);
        line(vc, mat, x1,y0,z0, x1,y1,z0, r,g,b,alpha);
        line(vc, mat, x1,y0,z1, x1,y1,z1, r,g,b,alpha);
        line(vc, mat, x0,y0,z1, x0,y1,z1, r,g,b,alpha);
    }

    private static void line(VertexConsumer vc, Matrix4f mat,
                             float x0,float y0,float z0,
                             float x1,float y1,float z1,
                             float r, float g, float b, float a) {
        // Forge/NeoForge 1.20: normal obrigatória para RenderType.lines()
        float nx = x1-x0, ny = y1-y0, nz = z1-z0;
        float len = (float)Math.sqrt(nx*nx+ny*ny+nz*nz);
        if (len == 0) { nx=0;ny=1;nz=0; } else { nx/=len;ny/=len;nz/=len; }
        vc.vertex(mat, x0,y0,z0).color(r,g,b,a).normal(nx,ny,nz).endVertex();
        vc.vertex(mat, x1,y1,z1).color(r,g,b,a).normal(nx,ny,nz).endVertex();
    }
}
