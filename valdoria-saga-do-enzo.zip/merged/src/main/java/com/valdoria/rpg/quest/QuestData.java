// [QuestData.java] — SUBSTITUI o original; expande para 101 missões
package com.valdoria.rpg.quest;
import com.valdoria.rpg.entity.EnzoGlacial;
import com.valdoria.rpg.entity.MalacharEntity;
import com.valdoria.rpg.registry.ModItems;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import static com.valdoria.rpg.quest.Quest.Type.*;
public final class QuestData {
    public static final String[] ACT_NAMES = {
            "Ato I - O Despertar", "Ato II - A Sombra se Aproxima", "Ato III - O Despertar do Nether",
            "Ato IV - A Jornada ao End", "Ato V - A Batalha Final",
            "Ato VI - O Portal Congelado", "Ato VII - Sobrevivência em Nivéria",
            "Ato VIII - O Templo Congelado", "Ato IX - O Castelo de Nivéria",
            "Ato X - A Batalha Final de Nivéria"};
    private static final List<Quest> Q = new ArrayList<>();
    private static void q(String title, Quest.Type t, String target, int amt, String lore, Consumer<ServerPlayer> reward) {
        int id = Q.size() + 1;
        int act = (id - 1) / 10 + 1;
        Q.add(new Quest(id, act, title, t, target, amt, lore, reward));
    }
    private static Consumer<ServerPlayer> essence() {
        return p -> QuestManager.give(p, new ItemStack(ModItems.GUARDIAN_ESSENCE.get()));
    }
    private static Consumer<ServerPlayer> essenceKey() {
        return p -> {
            QuestManager.give(p, new ItemStack(ModItems.GUARDIAN_ESSENCE.get()));
            QuestManager.give(p, new ItemStack(ModItems.DUNGEON_KEY.get()));
        };
    }
    static {
        q("A Chegada", HAVE, "minecraft:oak_log", 16, "Enzo abriu os olhos em um mundo estranho. Valdoria o recebeu com vento frio e bosques silenciosos. Madeira foi o primeiro passo para sobreviver.", null);
        q("O Rei Aldric", HAVE, "minecraft:cobblestone", 64, "Entre as árvores surgiu o Rei Aldric. 'Você é o Escolhido, Enzo. Mas antes da glória, precisa de pedra.'", null);
        q("A Pedra de Fundação", HAVE, "valdorianrpg:foundation_stone", 1, "No coração do vale repousa a Pedra de Fundação. Ao tocá-la, Enzo sentiu o chão de Valdoria acordar.", null);
        q("O Chão do Castelo", HAVE, "minecraft:oak_planks", 64, "Sobre a Pedra, Enzo ergueu o chão do castelo, tábua por tábua, sob o olhar atento de Aldric.", null);
        q("As Muralhas", HAVE, "minecraft:cobblestone", 128, "As muralhas começaram a subir. 'Um reino sem muros é apenas uma promessa', disse o rei.", null);
        q("Pedra Lapidada", HAVE, "minecraft:stone_bricks", 64, "A pedra lapidada trouxe ordem aos muros. O povo de Valdoria já olhava com esperança para o jovem construtor.", null);
        q("Portões de Ferro", HAVE, "minecraft:iron_ingot", 16, "O ferro forjou portões e dobradiças. O castelo, enfim, respirava.", null);
        q("Luz nas Muralhas", HAVE, "minecraft:torch", 32, "Tochas acesas ao longo dos muros afastaram as sombras da primeira noite de Valdoria.", null);
        q("A Profecia", KILL, "minecraft:zombie", 10, "Aldric revelou a profecia: 'Um ser de trevas, seu espelho, virá. Malachar, o Enzo Demoníaco.' Enzo empunhou a espada e enfrentou os primeiros mortos.", null);
        q("O Juramento", KILL, "minecraft:spider", 10, "A profecia está completa. Enzo jurou proteger Valdoria. O Ato I termina, e a hora de escolher um lado se aproxima.", essence());
        q("Luz ou Trevas", FACTION, "", 1, "Anjo ou Demônio. A escolha moldou a alma de Enzo e mudou a cor do vento sobre Valdoria.", null);
        q("As Torres", HAVE, "minecraft:iron_ingot", 32, "O castelo ganhou torres. Do alto, Enzo viu fumaça no horizonte: a sombra se aproximava.", null);
        q("A Primeira Invasão", KILL, "minecraft:zombie", 30, "Hordas de mortos cercaram os muros ao anoitecer. Enzo resistiu até o amanhecer.", null);
        q("Arqueiros de Osso", KILL, "minecraft:skeleton", 20, "Flechas cruzaram o céu escuro. Os esqueletos de Malachar testavam as defesas de Valdoria.", null);
        q("Explosões na Noite", KILL, "minecraft:creeper", 10, "Criaturas verdes rastejaram até as muralhas. Cada estrondo era um aviso do inimigo.", null);
        q("Recursos Raros", HAVE, "minecraft:diamond", 5, "Nas profundezas, Enzo encontrou diamantes. 'Isto forjará nossa esperança', disse Aldric.", null);
        q("O Ouro do Reino", HAVE, "minecraft:gold_ingot", 32, "O ouro adornou as torres e pagou os artesãos. Valdoria prosperava, apesar do medo.", null);
        q("Esmeraldas da Paz", HAVE, "minecraft:emerald", 10, "Aldeões trouxeram esmeraldas em troca de proteção. A aliança entre os povos se fortalecia.", null);
        q("Teias nas Sombras", KILL, "minecraft:spider", 25, "As aranhas tomaram a floresta ao redor. Enzo abriu caminho com fogo e aço.", null);
        q("O Coração das Torres", HAVE, "minecraft:diamond", 10, "As torres brilharam com diamantes. O Ato II termina, mas o céu já começava a avermelhar.", essence());
        q("O Céu Vermelho", HAVE, "minecraft:obsidian", 10, "O céu de Valdoria sangrou em vermelho. Malachar despertou o Nether. Enzo reuniu obsidiana para abrir o portal.", null);
        q("O Portal", DIM, "minecraft:the_nether", 1, "Enzo atravessou o portal. O calor queimou seus pulmões, e o Nether o encarou de volta.", null);
        q("Hastes de Blaze", HAVE, "minecraft:blaze_rod", 8, "Os Blazes guardavam a fortaleza em chamas. Enzo tomou suas hastes e seguiu adiante.", null);
        q("Os Piglins", KILL, "minecraft:piglin", 10, "Piglins de ouro e fúria bloquearam a trilha. Malachar os havia comprado com promessas.", null);
        q("Ouro Maldito", HAVE, "minecraft:gold_ingot", 64, "Enzo juntou ouro suficiente para a sala do trono, mas o metal parecia sussurrar o nome do inimigo.", null);
        q("Quartzo Branco", HAVE, "minecraft:quartz", 64, "O quartzo do Nether iluminou os corredores do castelo como pequenas estrelas.", null);
        q("Esqueletos Negros", KILL, "minecraft:wither_skeleton", 5, "Na fortaleza, Enzo enfrentou os guardas sombrios de Malachar e saiu vivo por pouco.", null);
        q("A Sala do Trono", HAVE, "minecraft:polished_blackstone_bricks", 64, "Pedra negra polida revestiu a sala do trono. Aldric sorriu: 'Agora Valdoria tem um coração.'", null);
        q("O Trono de Ouro", HAVE, "minecraft:gold_block", 9, "O trono foi forjado em ouro puro. Enzo sentou-se nele e sentiu o peso de ser o Escolhido.", null);
        q("Hordas de Malachar", KILL, "minecraft:zombified_piglin", 15, "Malachar enviou hordas do Nether contra o castelo. Enzo as derrotou e recebeu a Chave da Masmorra.", essenceKey());
        q("Pérolas do Fim", HAVE, "minecraft:ender_pearl", 12, "Aldric falou do End: 'Lá repousam os artefatos que podem deter Malachar.' Enzo partiu atrás de pérolas.", null);
        q("Olhos do Fim", HAVE, "minecraft:ender_eye", 12, "Com os Olhos de Ender, Enzo encontrou o caminho para a fortaleza escondida sob o mundo.", null);
        q("O Fim", DIM, "minecraft:the_end", 1, "O portal se abriu. Ilhas flutuantes, silêncio e um dragão adormecido esperavam por Enzo.", null);
        q("Os Altos", KILL, "minecraft:enderman", 15, "Os Endermans o observaram em silêncio. Cada um que caiu levou um eco do plano de Malachar.", null);
        q("Fruto do Coro", HAVE, "minecraft:chorus_fruit", 8, "O fruto do coro o levou entre ilhas distantes. Enzo aprendeu a confiar no salto no escuro.", null);
        q("Pedra do Fim", HAVE, "minecraft:end_stone", 64, "Pedra do End foi levada a Valdoria para selar os subterrâneos do castelo.", null);
        q("Púrpura Real", HAVE, "minecraft:purpur_block", 32, "As torres ganharam detalhes em púrpura, cor dos que enfrentam o abismo sem recuar.", null);
        q("Estrela do Nether", HAVE, "minecraft:nether_star", 1, "A Estrela do Nether brilhou nas mãos de Enzo. Com ela, o castelo teria seu farol.", null);
        q("O Farol de Valdoria", HAVE, "minecraft:beacon", 1, "No topo do castelo, o Farol acendeu. Sua luz atravessou o céu vermelho e chegou até os mais distantes.", null);
        q("Preparação para a Guerra", HAVE, "minecraft:diamond", 32, "A guerra final se aproximava. Enzo forjou, treinou e recebeu uma segunda Chave da Masmorra.", essenceKey());
        q("Maçãs Douradas", HAVE, "minecraft:golden_apple", 8, "Aldric entregou a Espada Definitiva de Valdoria: 'Ela será sua voz quando as palavras acabarem.'",
                p -> QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_SWORD.get())));
        q("O Dragão do End", KILL, "minecraft:ender_dragon", 1, "O Dragão do End caiu. O céu do Fim se calou e Enzo viu, ao longe, o brilho vermelho de Valdoria.", null);
        q("O Retorno", DIM, "minecraft:overworld", 1, "Enzo voltou a Valdoria. O reino o recebeu em silêncio, sabendo que a hora final havia chegado.", null);
        q("Essências do Guardião", HAVE, "valdorianrpg:guardian_essence", 3, "As Essências dos Guardiões vibraram em harmonia. Aldric disse que elas eram o último segredo do reino.", null);
        q("Totem da Esperança", HAVE, "minecraft:totem_of_undying", 1, "O totem repousou no peito de Enzo. Ao fundo, um forjador deixou a Armadura Definitiva diante dele.",
                p -> {
                    QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_HELMET.get()));
                    QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_CHESTPLATE.get()));
                    QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_LEGGINGS.get()));
                    QuestManager.give(p, new ItemStack(ModItems.ULTIMATE_BOOTS.get()));
                });
        q("A Espada Pronta", HAVE, "valdorianrpg:ultimate_sword", 1, "Com a espada em mãos, Enzo sentiu o peso da profecia. Não havia mais volta.", null);
        q("A Armadura Pronta", HAVE, "valdorianrpg:ultimate_chestplate", 1, "A armadura envolveu Enzo como uma segunda pele. Ele olhou no espelho e viu um herói.", null);
        q("A Chave Final", HAVE, "valdorianrpg:dungeon_key", 1, "A Chave da Masmorra girou. Das sombras abaixo do castelo ergueu-se Malachar, o Enzo Demoníaco.",
                p -> MalacharEntity.spawnNear(p));
        q("Enzo contra Malachar", FLAG, "malachar_dead", 1, "Dois Enzos, uma Valdoria. Aço contra fogo, Luz contra Trevas. Quando o último golpe caiu, só um deles continuou de pé.", null);
        q("O Portal de Nivéria", FLAG, "portal_niveria_entered", 1, "O céu de Valdoria voltou ao azul — por ora. Aldric apontou para um portal cintilante no pátio do castelo. 'Nivéria. Não é um mundo — é uma sala. Imensa, fechada, congelada para sempre. Entre com cuidado, Escolhido.'", null);
        // ===== ATO VI — O PORTAL CONGELADO (51-60) => índices 50-59 =====
        q("A Primeira Nevasca", FLAG, "nevasca_survived", 1, "Ao entrar na sala, Enzo foi golpeado por um frio sobrenatural. Não havia neve caindo — o ar em si era gelo. As paredes respiravam frio. Sem saída visível, ele teve que aguentar.", null);
        q("O Aviso de Aldric", FLAG, "aldric_found_niveria", 1, "Após 90 segundos na sala, Aldric apareceu como uma visão no gelo. 'Essa sala é Nivéria — um lugar congelado no tempo. O Enzo Glacial a criou para isolar o frio do mundo. Você é o único que pode encerrá-lo.'", null);
        q("O Abrigo de Emergência", HAVE, "minecraft:snow_block", 32, "Enzo ergueu um abrigo de neve para sobreviver à primeira noite glacial de Nivéria.", null);
        q("O Gelo Ancestral", HAVE, "minecraft:ice", 16, "Sob a neve profunda, Enzo encontrou blocos de gelo que guardavam memórias de um mundo esquecido.", null);
        q("A Passagem Secreta", FLAG, "passagem_secreta_found", 1, "Uma caverna oculta sob o castelo de Nivéria. As marcas nas paredes eram do próprio Enzo Glacial.", null);
        q("O Cristal Azul", HAVE, "minecraft:diamond", 8, "Diamantes pulsavam como cristais de gelo neste mundo. Enzo os coletou para forjar algo novo.", null);
        q("A Chave Congelada", HAVE, "valdorianrpg:chave_glacial", 1, "Com os diamantes e o gelo ancestral, Enzo forjou a Chave Glacial que abriria os segredos de Nivéria.", null);
        q("O Portal de Nivéria — Construção", FLAG, "portal_niveria_built", 1, "O portal dimensional ganhou forma. Enzo sentiu o frio aumentar enquanto o construía.", null);
        q("A Travessia", DIM, "valdorianrpg:niveria", 1, "Enzo cruzou o portal. O outro lado não era um mundo — era uma sala. Enorme, fechada, eterna. Paredes de neve sólida se erguiam até onde a vista alcançava, e o teto desaparecia na escuridão gelada. Nivéria não tinha céu.", null);
        q("Primeiro Contato", KILL, "valdorianrpg:criatura_congelada", 10, "As criaturas congeladas atacaram em silêncio. Enzo resistiu e provou que o frio não o quebraria.", null);
        // ===== ATO VII — SOBREVIVÊNCIA EM NIVÉRIA (61-70) => índices 60-69 =====
        q("Explorador do Gelo", FLAG, "ice_spikes_explored", 1, "Dentro da sala, picos de gelo azul cresciam do chão como dentes de um ser adormecido. Sem sol, sem céu — apenas o brilho frio do blue ice iluminando as paredes de neve. Enzo explorou cada canto dessa prisão gelada.", null);
        q("Madeira para Sobreviver", HAVE, "minecraft:spruce_log", 32, "Pinheiros congelados forneceram madeira. Enzo derrubou cada um com respeito pelo mundo gelado.", null);
        q("Comida Congelada", HAVE, "minecraft:bread", 16, "Comida era escassa em Nivéria. Enzo caçou e coletou o suficiente para continuar sua jornada.", null);
        q("A Vila Abandonada", FLAG, "vila_nevada_found", 1, "Dentro da sala, escondida entre picos de gelo, uma vila inteira congelada no tempo. Casas de neve, poços de gelo, e silêncio absoluto. Seus moradores foram encerrados aqui pelo Enzo Glacial há séculos.", null);
        q("O Ferreiro", HAVE, "minecraft:furnace", 1, "Enzo construiu uma fornalha com as pedras do mundo congelado. O calor do fogo era um conforto raro.", null);
        q("Armamento de Diamante", HAVE, "minecraft:diamond_sword", 1, "A espada de diamante foi forjada com os cristais de Nivéria. Ela brilhava com um frio letal.", null);
        q("A Mina Glacial", HAVE, "minecraft:diamond", 16, "As minas de Nivéria escondiam diamantes e segredos. Enzo escavou fundo, guiado pela luz azul.", null);
        q("A Defesa da Vila", KILL, "valdorianrpg:criatura_congelada", 15, "Hordas de criaturas congeladas cercaram a vila. Enzo as derrotou, protegendo o que restava.", null);
        q("O Primeiro Cristal", HAVE, "valdorianrpg:cristal_glacial", 1, "O Cristal Glacial brilhou nas mãos de Enzo. Era a essência concentrada de Nivéria.", null);
        q("O Guardião da Neve", FLAG, "guardiao_glacial_dead", 1, "O Guardião Glacial caiu. Sua armadura de gelo se partiu em mil fragmentos azuis.",
                p -> QuestManager.give(p, new ItemStack(ModItems.CRISTAL_GLACIAL.get(), 3)));
        // ===== ATO VIII — O TEMPLO CONGELADO (71-80) => índices 70-79 =====
        // Quest 70: troca de classe para Rei Secreto do Gelo
        q("O Segredo de Nivéria", FLAG, "rei_gelo_classe_desbloqueada", 1,
                "No centro do mundo congelado, uma voz ancestral sussurrou: 'Enzo, o frio não é seu inimigo — é seu poder. Torne-se o Rei Secreto do Gelo.' Pressione C para escolher a classe.",
                p -> {
                    p.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                            "§b❄ Classe 'Rei Secreto do Gelo' desbloqueada! Use [C] para equipá-la. Debuffs -40% e Redemoinho de Gelo [R]!"));
                });
        q("O Pico Proibido", FLAG, "montanha_nevada_top", 1, "Escalando os picos de gelo empacotado que cresciam do chão da sala, Enzo chegou ao ponto mais alto. Dali viu a vastidão da sala: paredes de neve em todos os lados, estruturas espalhadas na penumbra azulada. E ao fundo, a silhueta do Castelo de Gelo.", null);
        q("O Templo Antigo", FLAG, "templo_glacial_found", 1, "O Templo Glacial era uma estrutura de séculos de gelo cristalizado. Cada sala guardava um segredo.", null);
        q("Os Quatro Cristais", KILL, "valdorianrpg:esqueleto_congelado", 4, "Quatro cristais de gelo guardiões bloqueavam o caminho. Enzo os destruiu um a um.", null);
        q("Exército Congelado", KILL, "valdorianrpg:esqueleto_congelado", 20, "Esqueletos e criaturas congelados formavam o exército do templo. Enzo enfrentou todos.", null);
        q("A Biblioteca Perdida", FLAG, "livro_templo_found", 1, "Num baú selado pelo gelo, Enzo encontrou um livro escrito em runas antigas de Nivéria.", null);
        q("A Profecia de Nivéria", FLAG, "profecia_niveria_read", 1, "O livro revelava: 'Quando o Escolhido de Valdoria chegar, o gelo eterno terá fim ou um novo começo.'", null);
        q("O Coração de Gelo", HAVE, "valdorianrpg:fragmento_glacial", 4, "Quatro Fragmentos Glaciais foram coletados dos guardiões do templo. O Coração de Gelo começa a tomar forma.", null);
        q("A Forja Suprema", FLAG, "forja_glacial_built", 1, "Enzo construiu a Forja Glacial com pedras do templo e fogo da lava congelada de Nivéria.", null);
        q("A Espada Congelante", HAVE, "valdorianrpg:espada_glacial", 1, "A Espada Glacial foi forjada. Ela congelava o ar ao redor e a mente dos inimigos.",
                p -> QuestManager.give(p, new ItemStack(ModItems.ESPADA_GLACIAL.get())));
        q("O Senhor da Montanha", FLAG, "senhor_gelo_dead", 1, "O Senhor do Gelo caiu. Seu grito ecoou pelas montanhas de Nivéria.",
                p -> QuestManager.give(p, new ItemStack(ModItems.CRISTAL_GLACIAL.get(), 5)));
        // ===== ATO IX — O CASTELO DE NIVÉRIA (81-90) => índices 80-89 =====
        q("A Cidade Congelada", FLAG, "cidade_niveria_found", 1, "A cidade de Nivéria estava congelada no tempo. Estátuas de gelo de seus habitantes ainda guardavam as ruas.", null);
        q("A Muralha de Gelo", HAVE, "minecraft:ice", 64, "Enzo ergueu uma muralha de gelo ao redor do que restava da cidade. Proteção era necessária.", null);
        q("A Torre Glacial", FLAG, "torre_glacial_built", 1, "Uma torre de 15 blocos de altura marcou a presença de Enzo em Nivéria. Visível de longe no branco eterno.", null);
        q("O Arsenal de Nivéria", HAVE, "valdorianrpg:armadura_glacial_chestplate", 1, "A armadura glacial estava pronta. Enzo se vestiu com o frio como segunda pele.",
                p -> {
                    QuestManager.give(p, new ItemStack(ModItems.ARMADURA_GLACIAL_HELMET.get()));
                    QuestManager.give(p, new ItemStack(ModItems.ARMADURA_GLACIAL_LEGGINGS.get()));
                    QuestManager.give(p, new ItemStack(ModItems.ARMADURA_GLACIAL_BOOTS.get()));
                });
        q("A Chave do Castelo", HAVE, "valdorianrpg:chave_real", 1, "A Chave Real foi encontrada nas ruínas da sala do trono da cidade. Ela abriria o Castelo de Nivéria.", null);
        q("Os Guardas do Trono", KILL, "valdorianrpg:guardiao_glacial", 25, "Vinte e cinco guardiões congelados protegiam o castelo. Enzo os derrotou um a um.", null);
        q("O Dragão Glacial", FLAG, "dragao_gelo_dead", 1, "O Dragão de Gelo emergiu das sombras do teto da sala. Suas asas bateram contra as paredes de neve enquanto Enzo o enfrentou no interior congelado de Nivéria — sem céu, sem fuga.",
                p -> QuestManager.give(p, new ItemStack(ModItems.COROA_NIVERIA.get())));
        q("A Coroa Perdida", HAVE, "valdorianrpg:coroa_niveria", 1, "A Coroa de Nivéria estava nas cinzas do Dragão. Ela brilhava com uma luz azul eterna.", null);
        q("O Portal Dimensional", FLAG, "portal_arena_final_ativado", 1, "O portal para a arena final foi ativado com a Coroa. O Enzo Glacial o esperava.", null);
        q("Preparação para a Guerra Glacial", HAVE, "valdorianrpg:espada_glacial", 1, "Enzo verificou cada peça de sua armadura e cada fio de sua espada. A batalha final se aproximava.", null);
        // ===== ATO X — A BATALHA FINAL DE NIVÉRIA (91-100) => índices 90-100 =====
        q("A Entrada do Castelo", FLAG, "castelo_enzo_glacial_entered", 1, "Enzo entrou no castelo do Enzo Glacial. O frio ali era diferente: maligno, intencional.", null);
        q("Os Quatro Guardiões", KILL, "valdorianrpg:guardiao_glacial", 4, "Quatro guardiões especiais bloqueavam as quatro torres do castelo. Cada um guardava um segredo.", null);
        q("A Primeira Horda", KILL, "valdorianrpg:criatura_congelada", 30, "Trinta criaturas congeladas surgiram das paredes do castelo. Enzo as derrotou no corredor principal.", null);
        q("Os Fragmentos Finais", HAVE, "valdorianrpg:fragmento_glacial", 5, "Os cinco Fragmentos Glaciais reunidos vibraram com uma energia impossível de ignorar.", null);
        q("O Coração Completo", HAVE, "valdorianrpg:coracao_niveria", 1, "O Coração de Nivéria foi forjado com os cinco Fragmentos. Ele pulsava como o coração do próprio mundo.",
                p -> QuestManager.give(p, new ItemStack(ModItems.CORACAO_NIVERIA.get())));
        q("A Coroa do Enzo Glacial", HAVE, "valdorianrpg:coroa_niveria", 1, "Enzo colocou a Coroa de Nivéria. Por um momento, sentiu o peso de dois mundos sobre sua cabeça.", null);
        q("O Último Guardião", FLAG, "ultimo_guardiao_dead", 1, "O Guardião Final foi derrotado. Apenas o Enzo Glacial restava.", null);
        q("A Arena Final", FLAG, "arena_final_reached", 1, "O topo do castelo. Uma plataforma de gelo puro sobre o vazio de Nivéria. O vento uivava.", null);
        q("O Enzo Glacial", FLAG, "enzo_glacial_dead", 1, "O Enzo Glacial caiu. O frio eterno de Nivéria começou a derreter. A saga continua.",
                null);
        q("A Paz em Valdoria", DIM, "minecraft:overworld", 1, "Quando o Enzo Glacial caiu, as paredes da sala começaram a rachar. A sala de neve eterna desmoronou lentamente — e pela primeira vez, Enzo viu luz. De volta ao Overworld, Aldric sorriu: 'Você destruiu uma prisão de séculos, Escolhido. A saga nunca termina. Apenas os capítulos mudam.' FIM DE NIVÉRIA.", null);
    }
    private QuestData() {}
    public static int size() { return Q.size(); }
    public static Quest get(int id) { return Q.get(id - 1); }
    public static List<Quest> all() { return Q; }
    public static String actName(int act) {
        int idx = Math.max(0, Math.min(act - 1, ACT_NAMES.length - 1));
        return ACT_NAMES[idx];
    }
}
