// [FactionScreen.java] — Visual tecnológico profissional
package com.valdoria.rpg.client.screen;

import com.valdoria.rpg.network.FactionChoicePacket;
import com.valdoria.rpg.network.ModNetwork;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public class FactionScreen extends Screen {
    private static final int CARD_W = 148, CARD_H = 190;

    public FactionScreen() { super(Component.literal("Escolha sua Facção")); }

    private int leftX()  { return width / 2 - CARD_W - 12; }
    private int rightX() { return width / 2 + 12; }
    private int topY()   { return height / 2 - CARD_H / 2 - 14; }

    @Override
    public void render(GuiGraphics g, int mx, int my, float pt) {
        renderBackground(g);
        int lx = leftX(), rx = rightX(), ty = topY();

        // ─── Fundo geral ──────────────────────────────────────────────────
        int panW = CARD_W * 2 + 24, panH = CARD_H + 60;
        int panX = width / 2 - panW / 2, panY = ty - 28;
        g.fillGradient(panX, panY, panX + panW, panY + panH, 0xF2050A14, 0xF2020509);
        g.renderOutline(panX, panY, panW, panH, 0xFF00BFFF);
        for (int i = 0; i < panH; i += 5) g.fill(panX, panY + i, panX + panW, panY + i + 1, 0x06FFFFFF);

        // Header
        g.fill(panX, panY, panX + panW, panY + 22, 0xFF040E1A);
        g.fill(panX, panY + 22, panX + panW, panY + 23, 0xFF00BFFF);
        g.drawCenteredString(font, "§b⚡ O DESTINO DE ENZO — ESCOLHA SUA FACÇÃO", width / 2, panY + 7, 0xFF00DFFF);

        // Subtitle
        g.drawCenteredString(font, "§7Sua escolha moldará o poder de Valdoria para sempre",
                width / 2, ty - 6, 0xFF7EC8E3);

        // Cards
        card(g, lx, ty, true,  hov(mx, my, lx, ty));
        card(g, rx, ty, false, hov(mx, my, rx, ty));

        // Footer
        int fy = ty + CARD_H + 6;
        g.fill(panX, fy, panX + panW, fy + 1, 0xFF00BFFF);
        g.fill(panX, fy + 1, panX + panW, fy + 22, 0xFF030C16);
        g.drawCenteredString(font, "§7Clique em uma facção ou pressione  §e[1] Anjo  §c[2] Demônio",
                width / 2, fy + 8, 0xFF334455);

        super.render(g, mx, my, pt);
    }

    private boolean hov(int mx, int my, int cx, int ty) {
        return mx >= cx && mx <= cx + CARD_W && my >= ty && my <= ty + CARD_H;
    }

    private void card(GuiGraphics g, int x, int y, boolean angel, boolean hovered) {
        // Paleta
        int mainColor = angel ? 0xFF4488CC : 0xFFCC3322;
        int hlColor   = angel ? 0xFF88DDFF : 0xFFFF6644;
        int glowColor = angel ? 0x44AADDFF : 0x44FF6644;
        int bgTop     = angel ? (hovered ? 0xFF0A1E30 : 0xFF061420) : (hovered ? 0xFF200610 : 0xFF140308);
        int bgBot     = 0xFF020509;

        // Fundo
        g.fillGradient(x, y, x + CARD_W, y + CARD_H, bgTop, bgBot);
        // Borda
        g.renderOutline(x, y, CARD_W, CARD_H, hovered ? hlColor : mainColor);
        if (hovered) g.renderOutline(x + 2, y + 2, CARD_W - 4, CARD_H - 4, 0x44FFFFFF & hlColor);
        // Glow topo
        g.fillGradient(x, y, x + CARD_W, y + 36, (0xAA << 24 | (mainColor & 0x00FFFFFF)), 0x00000000);

        // Ícone de facção desenhado com guiGraphics
        int cx = x + CARD_W / 2, cy = y + 62;
        if (angel) drawAngel(g, cx, cy);
        else       drawDemon(g, cx, cy);

        // Nome e subtítulo
        String name  = angel ? "§e§l✦ ANJO §e§l✦" : "§c§l☽ DEMÔNIO ☽";
        String sub   = angel ? "§7Luz e Proteção" : "§7Trevas e Poder";
        g.drawCenteredString(font, name, cx, y + 112, angel ? 0xFFFFE066 : 0xFFFF6644);
        g.drawCenteredString(font, sub,  cx, y + 123, 0xFFBBBBBB);

        // Separador
        g.fill(x + 12, y + 133, x + CARD_W - 12, y + 134, hovered ? hlColor : mainColor);

        // Bônus
        String bonus1 = angel ? "§a+ Mana regenera mais" : "§c+ 15% de dano";
        String bonus2 = angel ? "§a+ Habilidades de cura" : "§c+ Invocações sombrias";
        g.drawCenteredString(font, bonus1, cx, y + 140, 0xFFDDDDDD);
        g.drawCenteredString(font, bonus2, cx, y + 151, 0xFFDDDDDD);

        // Hotkey
        String hk = angel ? "§8[1]" : "§8[2]";
        g.drawCenteredString(font, hk, cx, y + CARD_H - 14, 0xFF446688);

        // CTA hover
        if (hovered) {
            g.fill(x + 12, y + CARD_H - 26, x + CARD_W - 12, y + CARD_H - 10, glowColor);
            g.drawCenteredString(font, angel ? "§e→ ESCOLHER ANJO" : "§c→ ESCOLHER DEMÔNIO",
                    cx, y + CARD_H - 22, angel ? 0xFFFFE066 : 0xFFFF6644);
        }
    }

    private void drawAngel(GuiGraphics g, int cx, int cy) {
        // Asas
        g.fillGradient(cx - 42, cy - 6, cx - 14, cy + 22, 0xFFCCDDFF, 0xFF8899BB);
        g.fillGradient(cx + 14, cy - 6, cx + 42, cy + 22, 0xFFCCDDFF, 0xFF8899BB);
        // Penas das asas
        for (int i = 0; i < 3; i++) {
            g.fill(cx - 40 + i * 10, cy + 16, cx - 34 + i * 10, cy + 28, 0xFFBBCCFF);
            g.fill(cx + 20 + i * 10, cy + 16, cx + 26 + i * 10, cy + 28, 0xFFBBCCFF);
        }
        // Corpo
        g.fillGradient(cx - 10, cy - 4, cx + 10, cy + 28, 0xFFFFFFFF, 0xFFCCDDFF);
        // Cabeça
        g.fill(cx - 9, cy - 24, cx + 9, cy - 4, 0xFFFFE0BD);
        // Olhos
        g.fill(cx - 5, cy - 18, cx - 2, cy - 14, 0xFF2244AA);
        g.fill(cx + 2, cy - 18, cx + 5, cy - 14, 0xFF2244AA);
        // Boca
        g.fill(cx - 3, cy - 11, cx + 3, cy - 9, 0xFFFF9999);
        // Auréola (oval)
        g.fill(cx - 13, cy - 36, cx + 13, cy - 33, 0xFFFFE066);
        g.fill(cx - 15, cy - 33, cx + 15, cy - 31, 0xFFFFE066);
        g.fill(cx - 13, cy - 31, cx + 13, cy - 28, 0xFFFFE066);
        // Brilho auréola
        g.fill(cx - 13, cy - 34, cx - 11, cy - 29, 0xFFFFE066);
        g.fill(cx + 11, cy - 34, cx + 13, cy - 29, 0xFFFFE066);
    }

    private void drawDemon(GuiGraphics g, int cx, int cy) {
        // Asas
        g.fillGradient(cx - 44, cy - 8, cx - 14, cy + 20, 0xFF660022, 0xFF220008);
        g.fillGradient(cx + 14, cy - 8, cx + 44, cy + 20, 0xFF660022, 0xFF220008);
        // Nervuras das asas
        g.fill(cx - 38, cy - 6, cx - 36, cy + 16, 0xFF880033);
        g.fill(cx + 36, cy - 6, cx + 38, cy + 16, 0xFF880033);
        // Corpo
        g.fillGradient(cx - 10, cy - 4, cx + 10, cy + 28, 0xFF440011, 0xFF220008);
        // Cabeça
        g.fill(cx - 9, cy - 24, cx + 9, cy - 4, 0xFFAA1111);
        // Chifres curvos
        g.fill(cx - 14, cy - 38, cx - 10, cy - 24, 0xFF220000);
        g.fill(cx - 12, cy - 40, cx - 8, cy - 36, 0xFF220000);
        g.fill(cx + 10, cy - 38, cx + 14, cy - 24, 0xFF220000);
        g.fill(cx + 8, cy - 40, cx + 12, cy - 36, 0xFF220000);
        // Olhos (brilhantes)
        g.fill(cx - 6, cy - 18, cx - 2, cy - 13, 0xFFFFDD00);
        g.fill(cx + 2, cy - 18, cx + 6, cy - 13, 0xFFFFDD00);
        g.fill(cx - 5, cy - 17, cx - 3, cy - 14, 0xFFFF6600);
        g.fill(cx + 3, cy - 17, cx + 5, cy - 14, 0xFFFF6600);
        // Boca (sorriso)
        g.fill(cx - 5, cy - 10, cx + 5, cy - 8, 0xFF000000);
        g.fill(cx - 3, cy - 9, cx + 3, cy - 7, 0xFFFF2200);
        // Cauda
        g.fill(cx + 10, cy + 20, cx + 20, cy + 24, 0xFFAA1111);
        g.fill(cx + 20, cy + 24, cx + 26, cy + 28, 0xFFAA1111);
        g.fill(cx + 24, cy + 25, cx + 30, cy + 21, 0xFFAA1111);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (hov((int)mx, (int)my, leftX(), topY()))  { choose(1); return true; }
        if (hov((int)mx, (int)my, rightX(), topY())) { choose(2); return true; }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (key == GLFW.GLFW_KEY_1 || key == GLFW.GLFW_KEY_KP_1) { choose(1); return true; }
        if (key == GLFW.GLFW_KEY_2 || key == GLFW.GLFW_KEY_KP_2) { choose(2); return true; }
        return super.keyPressed(key, scan, mods);
    }

    private void choose(int faction) {
        ModNetwork.INSTANCE.sendToServer(new FactionChoicePacket(faction));
        onClose();
    }

    @Override public boolean isPauseScreen() { return false; }
}
