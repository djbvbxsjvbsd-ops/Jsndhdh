package com.valdoria.rpg.entity;

import com.valdoria.rpg.data.PlayerData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.network.chat.Component;

import java.util.List;

public class DragaoGelo extends Zombie {

    private final ServerBossEvent bossBar = new ServerBossEvent(
            Component.literal("§b❄ Dragão do Gelo"),
            BossEvent.BossBarColor.BLUE,
            BossEvent.BossBarOverlay.NOTCHED_10);

    private int phase = 1;

    public DragaoGelo(EntityType<? extends Zombie> type, Level level) {
        super(type, level);
        this.setCustomName(Component.literal("§b❄ Dragão do Gelo"));
        this.setCustomNameVisible(true);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 300.0D)
                .add(Attributes.ATTACK_DAMAGE, 20.0D)
                .add(Attributes.ARMOR, 12.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.38D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossBar.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossBar.removePlayer(player);
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;

        float health = this.getHealth();
        float maxHp = this.getMaxHealth();
        float ratio = health / maxHp;

        if (phase == 1 && ratio <= 0.65F) {
            phase = 2;
            this.playSound(SoundEvents.ENDER_DRAGON_GROWL, 1.0F, 0.6F);
            // Phase 2: freeze burst — freeze all players within 12 blocks
            freezeNearbyPlayers(12.0D, 4, 120);
            // Boost speed
            var speedAttr = this.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speedAttr != null) speedAttr.setBaseValue(0.50D);
        }
        if (phase == 2 && ratio <= 0.30F) {
            phase = 3;
            this.playSound(SoundEvents.WITHER_SPAWN, 1.0F, 0.5F);
            // Phase 3: enrage — massive freeze aura every 40 ticks
            var dmgAttr = this.getAttribute(Attributes.ATTACK_DAMAGE);
            if (dmgAttr != null) dmgAttr.setBaseValue(30.0D);
            var speedAttr = this.getAttribute(Attributes.MOVEMENT_SPEED);
            if (speedAttr != null) speedAttr.setBaseValue(0.60D);
        }

        // Phase 3 aura: freeze players every 40 ticks
        if (phase == 3 && tickCount % 40 == 0) {
            freezeNearbyPlayers(16.0D, 3, 80);
        }

        bossBar.setProgress(Math.max(0.0F, ratio));
    }

    private void freezeNearbyPlayers(double radius, int amplifier, int duration) {
        AABB box = this.getBoundingBox().inflate(radius);
        List<ServerPlayer> players = level().getEntitiesOfClass(ServerPlayer.class, box);
        for (ServerPlayer sp : players) {
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, duration, amplifier, false, true));
            sp.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, duration, 1, false, true));
        }
    }

    @Override
    public void die(DamageSource source) {
        super.die(source);
        // Award "dragao_gelo_dead" flag to all players within 50 blocks
        AABB box = this.getBoundingBox().inflate(50.0D);
        List<ServerPlayer> players = level().getEntitiesOfClass(ServerPlayer.class, box);
        for (ServerPlayer sp : players) {
            PlayerData.setFlag(sp, "dragao_gelo_dead");
            sp.sendSystemMessage(Component.literal("§b❄ O Dragão do Gelo foi derrotado! Sua jornada continua..."));
        }
        this.playSound(SoundEvents.ELDER_GUARDIAN_CURSE, 1.2F, 0.5F);
    }

    @Override
    protected boolean isSunSensitive() {
        return false;
    }
}
