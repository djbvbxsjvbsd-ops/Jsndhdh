// [HudOverlay.java] — HUD tecnológico com classe e poder do Rei do Gelo
package com.valdoria.rpg.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.InventoryScreen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraftforge.client.gui.overlay.ForgeGui;

public class HudOverlay {
    private static final int PW = 136, PH = 72, MARGIN = 4;
    private static final float TEXT_SCALE = 0.62F;

    public static void render(ForgeGui gui, GuiGraphics g, float partialTick, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer p = mc.player;
        if (p == null || mc.options.hideGui || !ClientData.hudVisible) return;

        double guiScale = mc.getWindow().getGuiScale();
        float target = Math.max(200F, Math.min(mc.getWindow().getWidth() * 0.22F, 340F));
        float s = (float)(target / (PW * guiScale));
        s = Math.max(0.5F, Math.min(s, 2.0F));
        s = Math.min(s, (h * 0.42F) / PH);

        g.pose().pushPose();
        g.pose().translate(MARGIN, MARGIN, 0F);
        g.pose().scale(s, s, 1F);

        boolean ice = ClientData.inNiveria || ClientData.isIceKing();
        int borderColor = ice ? 0xFF88EEFF : 0xFF00BFFF;
        int accentColor = ice ? 0xFF1188CC : 0xFF0055AA;

        // Fundo com gradiente tech
        g.fillGradient(0, 0, PW, PH, 0xCC040E1A, 0xCC020609);
        // Scanlines
        for (int i = 0; i < PH; i += 4) g.fill(0, i, PW, i + 1, 0x08FFFFFF);
        // Borda principal
        g.renderOutline(0, 0, PW, PH, borderColor);
        g.renderOutline(1, 1, PW - 2, PH - 2, 0x22FFFFFF);
        // Header stripe
        g.fill(0, 0, PW, 10, 0xFF040E1A);
        g.fill(0, 10, PW, 11, accentColor);

        // Avatar
        InventoryScreen.renderEntityInInventoryFollowsMouse(g, 12, 48, 14, 12F, -4F, p);

        // Header: nome e classe
        String classIcon = switch (ClientData.playerClass) {
            case 1 -> "⚔"; case 2 -> "✦"; case 3 -> "➶"; case 4 -> "❄"; default -> "◌";
        };
        text(g, mc.font, "§b" + classIcon + " " + p.getName().getString(), 2, 2, borderColor);

        int bx = 28, bw = 90, bh = 7;
        // HP bar
        bar(g, mc.font, bx, 12, bw, bh, p.getHealth() / Math.max(1F, p.getMaxHealth()),
                0xFFFF4455, "§c♥", String.format("%.0f/%.0f", p.getHealth(), p.getMaxHealth()));
        // Mana bar
        bar(g, mc.font, bx, 21, bw, bh, ClientData.mana / Math.max(1F, ClientData.maxMana),
                0xFF2979FF, "§9✦", String.format("%.0f", ClientData.mana));
        // XP bar
        bar(g, mc.font, bx, 30, bw, bh, p.experienceProgress,
                0xFF43A047, "§a⬆", "Nv " + p.experienceLevel);
        // Fome bar
        bar(g, mc.font, bx, 39, bw, bh, p.getFoodData().getFoodLevel() / 20F,
                0xFFFF9900, "§6🍖", "" + p.getFoodData().getFoodLevel());

        // Ato e missões
        text(g, mc.font, "§7Ato §e" + ClientData.act() + " §7| §f" + Math.min(101, ClientData.completed + 1) + "/101",
                bx, 50, 0xFFE0B040);

        // Linha de Nivéria / Rei do Gelo
        if (ClientData.isIceKing()) {
            String cdStr = ClientData.whirlpoolCooldown > 0
                    ? "§cCD:" + (ClientData.whirlpoolCooldown / 20) + "s"
                    : "§a[R]";
            text(g, mc.font, "§b❄ Rei do Gelo  " + cdStr, bx, 60, 0xFF88DDFF);
        } else if (ClientData.inNiveria) {
            text(g, mc.font, "§b❄ Nivéria  Frags:" + ClientData.fragmentosGlaciais, bx, 60, 0xFF88CCFF);
        }

        g.pose().popPose();
    }

    private static void bar(GuiGraphics g, Font font, int x, int y, int w, int h,
                            float frac, int color, String icon, String val) {
        frac = Math.max(0F, Math.min(1F, frac));
        g.fill(x, y, x + w, y + h, 0xFF000000);
        g.fill(x + 1, y + 1, x + w - 1, y + h - 1, 0xFF050D18);
        int filled = (int)((w - 2) * frac);
        if (filled > 0) {
            g.fillGradient(x + 1, y + 1, x + 1 + filled, y + h - 1, color, darken(color, 0.55F));
        }
        text(g, font, icon, x - 7, y + 1, color);
        text(g, font, "§f" + val, x + 3, y + 1, 0xFFFFFFFF);
    }

    private static void text(GuiGraphics g, Font font, String t, int x, int y, int color) {
        g.pose().pushPose();
        g.pose().scale(TEXT_SCALE, TEXT_SCALE, 1F);
        g.drawString(font, t, (int)(x / TEXT_SCALE), (int)(y / TEXT_SCALE), color, false);
        g.pose().popPose();
    }

    private static int darken(int color, float f) {
        int r = (int)(((color >> 16) & 0xFF) * f);
        int gv = (int)(((color >> 8) & 0xFF) * f);
        int b = (int)((color & 0xFF) * f);
        return (color & 0xFF000000) | (r << 16) | (gv << 8) | b;
    }
}
