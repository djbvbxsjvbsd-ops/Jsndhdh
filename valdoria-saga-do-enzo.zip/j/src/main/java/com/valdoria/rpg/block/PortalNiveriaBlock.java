package com.valdoria.rpg.block;

import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;

public class PortalNiveriaBlock extends Block {

    /**
     * Y seguro do piso de Nivéria (PISO_Y=10 + 3 packed ice + 1 ice + 1 snow + 1 acima = 16).
     * Player nasce em cima da neve, não abaixo do mapa.
     */
    private static final int NIVERIA_SPAWN_Y = 16;

    public PortalNiveriaBlock(Properties props) { super(props); }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        if (level.isClientSide || !(entity instanceof ServerPlayer sp)) return;
        if (sp.isOnPortalCooldown()) { sp.setPortalCooldown(); return; }

        boolean emNiveria = sp.level().dimension().equals(NiveriaDimension.NIVERIA);

        if (emNiveria) {
            // ===== PORTAL DE VOLTA — Nivéria → Overworld =====
            ServerLevel overworld = sp.getServer().getLevel(Level.OVERWORLD);
            if (overworld == null) return;

            BlockPos owSpawn = overworld.getSharedSpawnPos();
            int owY = overworld.getHeight(
                    Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                    owSpawn.getX(), owSpawn.getZ()) + 1;

            sp.teleportTo(overworld,
                    owSpawn.getX() + 0.5D, owY, owSpawn.getZ() + 0.5D,
                    sp.getYRot(), sp.getXRot());
            sp.setPortalCooldown();
            sp.sendSystemMessage(Component.literal(
                    "§a✦ Você retornou a Valdoria. Boa sorte, Escolhido."));

        } else {
            // ===== PORTAL DE IDA — Overworld → Nivéria =====
            ServerLevel niveria = sp.getServer().getLevel(NiveriaDimension.NIVERIA);
            if (niveria == null) return;

            // Spawn fixo em (0, NIVERIA_SPAWN_Y, 0) — centro do piso da sala
            sp.teleportTo(niveria,
                    0.5D, NIVERIA_SPAWN_Y, 0.5D,
                    sp.getYRot(), sp.getXRot());
            sp.setPortalCooldown();
        }
    }
}
