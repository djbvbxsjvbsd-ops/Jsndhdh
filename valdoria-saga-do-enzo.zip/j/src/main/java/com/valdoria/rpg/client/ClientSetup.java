package com.valdoria.rpg.client;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.client.renderer.EnzoGlacialRenderer;
import com.valdoria.rpg.registry.ModEntities;
import net.minecraft.client.renderer.entity.IronGolemRenderer;
import net.minecraft.client.renderer.entity.SkeletonRenderer;
import net.minecraft.client.renderer.entity.WitherSkeletonRenderer;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(KeyMappings.PROFILE);
        e.register(KeyMappings.MAP);
        e.register(KeyMappings.HUD);
        e.register(KeyMappings.CLASS_SCR);
        e.register(KeyMappings.WHIRLPOOL);
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("valdoria_hud", HudOverlay::render);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.MALACHAR.get(),            ZombieRenderer::new);
        e.registerEntityRenderer(ModEntities.CRIATURA_CONGELADA.get(),  ZombieRenderer::new);
        e.registerEntityRenderer(ModEntities.ESQUELETO_CONGELADO.get(), SkeletonRenderer::new);
        e.registerEntityRenderer(ModEntities.GUARDIAO_GLACIAL.get(),    IronGolemRenderer::new);
        e.registerEntityRenderer(ModEntities.SENHOR_GELO.get(),         WitherSkeletonRenderer::new);
        // ✅ EnzoGlacial agora usa o renderer personalizado com aura
        e.registerEntityRenderer(ModEntities.ENZO_GLACIAL.get(),        EnzoGlacialRenderer::new);
        e.registerEntityRenderer(ModEntities.DRAGAO_GELO.get(),         ZombieRenderer::new);
    }
}
