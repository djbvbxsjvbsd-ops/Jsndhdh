// [QuestEsp.java] — ESP colorido do alvo da quest atual — MELHORADO
package com.valdoria.rpg.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

import java.util.ArrayList;
import java.util.List;

/**
 * Renderiza bounding-box colorida ao redor do alvo da quest ativa.
 * Chamado a partir de ClientEvents.renderLevel (RenderLevelStageEvent).
 *
 * FIX ESP: Antes o ESP podia falhar silenciosamente quando o ResourceLocation
 * do alvo era inválido ou o tipo de entidade não era encontrado no nível.
 * Agora com try-catch granular e log de debug no chat para facilitar diagnóstico.
 */
public final class QuestEsp {

    private QuestEsp() {}

    /** Cor RGB por ato (igual ao sistema de highlight do servidor). */
    public static int[] actColor(int questId) {
        if (questId <= 10)  return new int[]{255, 215,   0};   // dourado
        if (questId <= 20)  return new int[]{255, 200,  50};   // amarelo
        if (questId <= 30)  return new int[]{255,  60,  60};   // vermelho
        if (questId <= 40)  return new int[]{255,  80, 255};   // magenta
        if (questId <= 50)  return new int[]{255, 255, 255};   // branco
        if (questId <= 60)  return new int[]{  0, 220, 255};   // ciano
        if (questId <= 70)  return new int[]{ 50, 220,  50};   // verde
        if (questId <= 80)  return new int[]{ 60, 120, 255};   // azul
        if (questId <= 90)  return new int[]{180,   0, 255};   // roxo
        return                     new int[]{180,   0,   0};   // vermelho escuro
    }

    /**
     * Renderiza ESP para o alvo atual da quest.
     * @param poseStack PoseStack do RenderLevelStageEvent
     * @param bufferSource MultiBufferSource da cena
     */
    public static void render(PoseStack poseStack, MultiBufferSource bufferSource) {
        int type   = ClientData.questTargetType;
        String tgt = ClientData.questTarget;
        int qId    = ClientData.questId;

        if (type == 0 || tgt == null || tgt.isEmpty()) return;

        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || mc.player == null) return;

        int[] rgb = actColor(qId);
        float r = rgb[0] / 255f, g = rgb[1] / 255f, b = rgb[2] / 255f;

        Vec3 cam = mc.gameRenderer.getMainCamera().getPosition();

        if (type == 1) {
            // KILL — destaca entidades cujo tipo bate com o alvo
            ResourceLocation rl;
            try {
                rl = new ResourceLocation(tgt);
            } catch (Exception ex) {
                // ResourceLocation inválida — limpa o alvo para evitar spam
                ClientData.updateQuestTarget(0, "", 0);
                return;
            }

            // FIX: verificar se o tipo existe no registry antes de comparar
            if (!BuiltInRegistries.ENTITY_TYPE.containsKey(rl)) return;

            List<Entity> entities = new ArrayList<>();
            for (Entity en : mc.level.entitiesForRendering()) {
                ResourceLocation enKey = BuiltInRegistries.ENTITY_TYPE.getKey(en.getType());
                if (enKey != null && enKey.equals(rl)) {
                    entities.add(en);
                }
            }

            for (Entity en : entities) {
                double dx = en.getX() - cam.x;
                double dy = en.getY() - cam.y;
                double dz = en.getZ() - cam.z;
                if (dx * dx + dy * dy + dz * dz > 128 * 128) continue;

                AABB bb = en.getBoundingBox().move(-cam.x, -cam.y, -cam.z);
                // Linha sólida (alpha 1.0 = totalmente visível)
                drawBox(poseStack, bufferSource, bb, r, g, b, 1.0f);
                // Segunda caixa ligeiramente maior pulsando com alpha menor
                float pulse = (float)(Math.sin(System.currentTimeMillis() * 0.005) * 0.3 + 0.4);
                drawBox(poseStack, bufferSource, bb.inflate(0.1), r, g, b, pulse);
            }

        } else if (type == 2) {
            // HAVE — destaca ItemEntity no chão cujo item bate
            ResourceLocation rl;
            try {
                rl = new ResourceLocation(tgt);
            } catch (Exception ex) {
                ClientData.updateQuestTarget(0, "", 0);
                return;
            }

            // FIX: verificar se o item existe
            if (!BuiltInRegistries.ITEM.containsKey(rl)) return;

            Item wantedItem = BuiltInRegistries.ITEM.get(rl);

            List<ItemEntity> items = mc.level.getEntitiesOfClass(ItemEntity.class,
                    mc.player.getBoundingBox().inflate(64));

            for (ItemEntity ie : items) {
                ItemStack stack = ie.getItem();
                if (stack.isEmpty() || !stack.is(wantedItem)) continue;

                double dx = ie.getX() - cam.x;
                double dy = ie.getY() - cam.y;
                double dz = ie.getZ() - cam.z;
                if (dx * dx + dy * dy + dz * dz > 64 * 64) continue;

                AABB bb = ie.getBoundingBox().move(-cam.x, -cam.y, -cam.z).inflate(0.2);
                drawBox(poseStack, bufferSource, bb, r, g, b, 1.0f);
            }
        }
        // Tipo 3 (FLAG/DIM/FACTION) — sem ESP visual
    }

    // -------------------------------------------------------------------------
    // Desenha bounding-box colorida (visível através de blocos — depth test desligado
    // via RenderSystem no ClientEvents ANTES de chamar este método)
    // -------------------------------------------------------------------------
    private static void drawBox(PoseStack ps, MultiBufferSource buf,
                                AABB bb, float r, float g, float b, float alpha) {
        // FIX: usar LINES com normal correta (obrigatória no Forge 1.20.x)
        VertexConsumer vc = buf.getBuffer(RenderType.lines());
        Matrix4f mat = ps.last().pose();

        float x0 = (float) bb.minX, y0 = (float) bb.minY, z0 = (float) bb.minZ;
        float x1 = (float) bb.maxX, y1 = (float) bb.maxY, z1 = (float) bb.maxZ;

        // 12 arestas do cubo
        // Fundo
        line(vc, mat, x0,y0,z0, x1,y0,z0, r,g,b,alpha);
        line(vc, mat, x1,y0,z0, x1,y0,z1, r,g,b,alpha);
        line(vc, mat, x1,y0,z1, x0,y0,z1, r,g,b,alpha);
        line(vc, mat, x0,y0,z1, x0,y0,z0, r,g,b,alpha);
        // Topo
        line(vc, mat, x0,y1,z0, x1,y1,z0, r,g,b,alpha);
        line(vc, mat, x1,y1,z0, x1,y1,z1, r,g,b,alpha);
        line(vc, mat, x1,y1,z1, x0,y1,z1, r,g,b,alpha);
        line(vc, mat, x0,y1,z1, x0,y1,z0, r,g,b,alpha);
        // Laterais
        line(vc, mat, x0,y0,z0, x0,y1,z0, r,g,b,alpha);
        line(vc, mat, x1,y0,z0, x1,y1,z0, r,g,b,alpha);
        line(vc, mat, x1,y0,z1, x1,y1,z1, r,g,b,alpha);
        line(vc, mat, x0,y0,z1, x0,y1,z1, r,g,b,alpha);
    }

    private static void line(VertexConsumer vc, Matrix4f mat,
                             float x0, float y0, float z0,
                             float x1, float y1, float z1,
                             float r, float g, float b, float a) {
        float nx = x1-x0, ny = y1-y0, nz = z1-z0;
        float len = (float) Math.sqrt(nx*nx + ny*ny + nz*nz);
        if (len == 0) { nx = 0; ny = 1; nz = 0; } else { nx /= len; ny /= len; nz /= len; }
        vc.vertex(mat, x0, y0, z0).color(r, g, b, a).normal(nx, ny, nz).endVertex();
        vc.vertex(mat, x1, y1, z1).color(r, g, b, a).normal(nx, ny, nz).endVertex();
    }
}
