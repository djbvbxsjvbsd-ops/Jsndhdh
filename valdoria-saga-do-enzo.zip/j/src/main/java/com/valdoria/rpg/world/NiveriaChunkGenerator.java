// [NiveriaChunkGenerator.java] — CORRIGIDO: spawn acima do piso, não dentro do chão
package com.valdoria.rpg.world;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.RegistryAccess;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.LevelHeightAccessor;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.NoiseColumn;
import net.minecraft.world.level.StructureManager;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.BiomeManager;
import net.minecraft.world.level.biome.BiomeSource;
import net.minecraft.world.level.biome.FixedBiomeSource;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraft.world.level.chunk.ChunkGeneratorStructureState;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.RandomState;
import net.minecraft.world.level.levelgen.blending.Blender;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplateManager;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

/**
 * Nivéria: sala gigante de neve.
 *
 * BUG CORRIGIDO (print): o jogador spawnava DENTRO do chão porque o getBaseHeight()
 * retornava PISO_Y+5 (topo das camadas de blocos), mas o spawn system usava
 * esse valor como Y e o jogador aparecia preso entre os blocos de neve.
 *
 * FIX: getBaseHeight() agora retorna PISO_Y + 5 + 1 = SPAWN_Y (o primeiro Y de AR),
 * e a camada de neve foi ajustada para terminar exatamente em PISO_Y+4, deixando
 * PISO_Y+5 livre (ar). Assim o jogador spawna EM CIMA da neve, não dentro dela.
 *
 * Piso: pedra (0..PISO_Y-1) → packed ice (PISO_Y..PISO_Y+2) → ice (PISO_Y+3) → snow (PISO_Y+4)
 * Primeiro bloco de AR: PISO_Y + 5  ← spawn aqui
 */
public class NiveriaChunkGenerator extends ChunkGenerator {

    public static final Codec<NiveriaChunkGenerator> CODEC = RecordCodecBuilder.create(inst ->
            inst.group(BiomeSource.CODEC.fieldOf("biome_source").forGetter(g -> g.biomeSource))
                    .apply(inst, NiveriaChunkGenerator::new));

    // Sala de 512 blocos de raio ao redor da origem (1024x1024 de espaço interno)
    private static final int SALA_RAIO   = 512;
    // Altura interna da sala (do piso ao teto)
    private static final int SALA_ALTURA = 60;
    // Y do piso (base sólida)
    public  static final int PISO_Y      = 10;
    // ✅ FIX: Y do primeiro bloco de AR (onde o jogador spawna)
    //    Piso ocupa Y=10..14 (5 camadas: packed*3 + ice + snow)
    //    Y=15 é o primeiro ar → spawn correto
    public  static final int SPAWN_Y     = PISO_Y + 5;
    // Y do teto
    private static final int TETO_Y      = PISO_Y + SALA_ALTURA;
    // Espessura das paredes
    private static final int PAREDE_ESP  = 5;

    public NiveriaChunkGenerator(BiomeSource biomeSource) { super(biomeSource); }

    public static NiveriaChunkGenerator create(HolderLookup.Provider lookup) {
        Holder<Biome> iceBiome = lookup.lookupOrThrow(net.minecraft.core.registries.Registries.BIOME)
                .getOrThrow(net.minecraft.world.level.biome.Biomes.ICE_SPIKES);
        return new NiveriaChunkGenerator(new FixedBiomeSource(iceBiome));
    }

    @Override protected Codec<? extends ChunkGenerator> codec() { return CODEC; }

    @Override
    public void buildSurface(WorldGenRegion region, StructureManager sm, RandomState random, ChunkAccess chunk) {
        int cx = chunk.getPos().getMinBlockX();
        int cz = chunk.getPos().getMinBlockZ();

        for (int lx = 0; lx < 16; lx++) {
            for (int lz = 0; lz < 16; lz++) {
                int wx = cx + lx;
                int wz = cz + lz;

                boolean dentroX = Math.abs(wx) < SALA_RAIO;
                boolean dentroZ = Math.abs(wz) < SALA_RAIO;
                boolean dentro  = dentroX && dentroZ;

                if (dentro) {
                    // === INTERIOR DA SALA ===

                    // Piso: pedra → packed ice × 3 → ice → snow
                    // Camadas: Y=0..9 = pedra, Y=10..12 = packed ice, Y=13 = ice, Y=14 = snow
                    for (int y = 0; y < PISO_Y; y++)
                        setBlock(chunk, wx, y, wz, Blocks.STONE.defaultBlockState());

                    // packed ice: Y=10, 11, 12
                    setBlock(chunk, wx, PISO_Y,     wz, Blocks.PACKED_ICE.defaultBlockState());
                    setBlock(chunk, wx, PISO_Y + 1, wz, Blocks.PACKED_ICE.defaultBlockState());
                    setBlock(chunk, wx, PISO_Y + 2, wz, Blocks.PACKED_ICE.defaultBlockState());

                    // ice: Y=13
                    setBlock(chunk, wx, PISO_Y + 3, wz, Blocks.ICE.defaultBlockState());

                    // snow: Y=14  ← topo do piso
                    setBlock(chunk, wx, PISO_Y + 4, wz, Blocks.SNOW_BLOCK.defaultBlockState());

                    // ✅ Y=15 (SPAWN_Y) deve ser AR — não colocar bloco aqui!
                    // Interior vazio entre o ar do spawn e o teto
                    for (int y = SPAWN_Y; y < TETO_Y; y++)
                        setBlock(chunk, wx, y, wz, Blocks.AIR.defaultBlockState());

                    // Teto: neve compacta
                    for (int y = TETO_Y; y <= TETO_Y + PAREDE_ESP; y++)
                        setBlock(chunk, wx, y, wz, Blocks.SNOW_BLOCK.defaultBlockState());

                    // Paredes nas bordas da sala
                    boolean bordaX = Math.abs(wx) >= SALA_RAIO - PAREDE_ESP;
                    boolean bordaZ = Math.abs(wz) >= SALA_RAIO - PAREDE_ESP;
                    if (bordaX || bordaZ) {
                        for (int y = PISO_Y; y <= TETO_Y + PAREDE_ESP; y++)
                            setBlock(chunk, wx, y, wz, Blocks.PACKED_ICE.defaultBlockState());
                    }

                    // Picos de gelo internos (decoração) — começam em SPAWN_Y para não obstruir
                    if (isIceSpike(wx, wz) && !bordaX && !bordaZ) {
                        int spikeH = 3 + (Math.abs(wx * 7919 + wz * 1013) % 8);
                        for (int sy = 0; sy < spikeH; sy++)
                            setBlock(chunk, wx, SPAWN_Y + sy, wz, Blocks.PACKED_ICE.defaultBlockState());
                    }

                    // Stalactites de gelo no teto
                    if (isStalactite(wx, wz) && !bordaX && !bordaZ) {
                        int stH = 2 + (Math.abs(wx * 1009 + wz * 7727) % 6);
                        for (int sy = 0; sy < stH; sy++)
                            setBlock(chunk, wx, TETO_Y - 1 - sy, wz, Blocks.BLUE_ICE.defaultBlockState());
                    }

                    // Gelo azul aleatório no chão (brilho) — na camada de snow do topo do piso
                    if (isBlueIcePatch(wx, wz))
                        setBlock(chunk, wx, PISO_Y + 4, wz, Blocks.BLUE_ICE.defaultBlockState());

                } else {
                    // === FORA DA SALA: sólido de neve/pedra ===
                    for (int y = 0; y <= TETO_Y + PAREDE_ESP + 5; y++)
                        setBlock(chunk, wx, y, wz,
                                y < PISO_Y ? Blocks.STONE.defaultBlockState() : Blocks.SNOW_BLOCK.defaultBlockState());
                }
            }
        }
    }

    private void setBlock(ChunkAccess chunk, int wx, int y, int wz, BlockState state) {
        if (y < -64 || y > 319) return;
        chunk.setBlockState(new BlockPos(wx, y, wz), state, false);
    }

    private boolean isIceSpike(int x, int z) {
        long h = (long)x * 341873128712L + (long)z * 132897987541L;
        return (h ^ (h >> 17)) % 18 == 0;
    }

    private boolean isStalactite(int x, int z) {
        long h = (long)x * 987654321L + (long)z * 123456789L;
        return (h ^ (h >> 13)) % 22 == 0;
    }

    private boolean isBlueIcePatch(int x, int z) {
        long h = (long)x * 1664525L + (long)z * 1013904223L;
        return (h ^ (h >> 9)) % 30 == 0;
    }

    @Override
    public void applyCarvers(WorldGenRegion r, long seed, RandomState rng, BiomeManager bm,
            StructureManager sm, ChunkAccess chunk, GenerationStep.Carving step) {}

    @Override public void spawnOriginalMobs(WorldGenRegion r) {}
    @Override public int getGenDepth() { return 384; }

    @Override
    public CompletableFuture<ChunkAccess> fillFromNoise(Executor ex, Blender bl,
            RandomState rng, StructureManager sm, ChunkAccess chunk) {
        return CompletableFuture.completedFuture(chunk);
    }

    @Override public int getSeaLevel() { return PISO_Y; }
    @Override public int getMinY() { return -64; }

    /**
     * ✅ FIX CRÍTICO: retorna SPAWN_Y (primeiro bloco de ar) para que o
     * sistema de spawn coloque o jogador ACIMA do chão, não dentro dele.
     */
    @Override
    public int getBaseHeight(int x, int z, Heightmap.Types t, LevelHeightAccessor lvl, RandomState rng) {
        return SPAWN_Y; // Y=15: primeiro bloco livre acima da neve
    }

    @Override
    public NoiseColumn getBaseColumn(int x, int z, LevelHeightAccessor lvl, RandomState rng) {
        BlockState[] states = new BlockState[SPAWN_Y + 64];
        for (int y = 0; y <= PISO_Y + 4; y++) states[y + 64] = Blocks.PACKED_ICE.defaultBlockState();
        for (int y = PISO_Y + 5; y < SPAWN_Y + 64; y++) states[y + 64] = Blocks.AIR.defaultBlockState();
        return new NoiseColumn(-64, states);
    }

    @Override public void addDebugScreenInfo(List<String> info, RandomState rng, BlockPos pos) {}
    @Override public void applyBiomeDecoration(WorldGenLevel region, ChunkAccess chunk, StructureManager sm) {}
    @Override public void createStructures(RegistryAccess access, ChunkGeneratorStructureState state,
            StructureManager sm, ChunkAccess chunk, StructureTemplateManager stm) {}
    @Override public void createReferences(WorldGenLevel region, StructureManager sm, ChunkAccess chunk) {}
}
