package com.valdoria.rpg.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.entity.EnzoGlacial;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.ZombieModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ZombieRenderer;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.resources.ResourceLocation;
import org.joml.Matrix4f;

/**
 * Renderer do EnzoGlacial — cara baseada na foto do Enzo (jovem com óculos,
 * pele morena, cabelo enrolado), aura PRETA pulsante + aura AMARELA ao morrer.
 */
public class EnzoGlacialRenderer extends ZombieRenderer {

    // Textura facial personalizada inspirada na foto (jovem com óculos, cabelo curto enrolado)
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(ValdoriaMod.MODID, "textures/entity/enzo_glacial.png");

    public EnzoGlacialRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        // Adiciona a camada de aura
        this.addLayer(new AuraLayer(this));
    }

    @Override
    public ResourceLocation getTextureLocation(EnzoGlacial entity) {
        return TEXTURE;
    }

    // =========================================================================
    // LAYER DE AURA
    // =========================================================================
    private static class AuraLayer extends RenderLayer<EnzoGlacial, ZombieModel<EnzoGlacial>> {

        public AuraLayer(EnzoGlacialRenderer renderer) {
            super(renderer);
        }

        @Override
        public void render(PoseStack ps, MultiBufferSource buf, int light,
                           EnzoGlacial entity, float limbSwing, float limbSwingAmount,
                           float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {

            float hpPct = entity.getHealth() / entity.getMaxHealth();
            boolean morrendо = hpPct < 0.25f && entity.isAlive();

            // Pulso temporal: sin^2 para suavidade
            float pulse = (float) Math.pow(Math.sin(ageInTicks * 0.12f), 2);

            if (morrendо) {
                // AURA AMARELA: intensa quando quase morto
                float alpha = 0.35f + 0.35f * pulse;
                renderAuraBox(ps, buf, entity, 1.0f, 0.85f, 0.0f, alpha, ageInTicks, 1.20f);
                // Segunda camada mais ampla para efeito "queimando"
                renderAuraBox(ps, buf, entity, 1.0f, 0.6f, 0.0f, alpha * 0.5f, ageInTicks, 1.38f);
            } else {
                // AURA PRETA: partículas escuras ao redor
                float alpha = 0.25f + 0.20f * pulse;
                renderAuraBox(ps, buf, entity, 0.05f, 0.05f, 0.08f, alpha, ageInTicks, 1.18f);
                // Halo externo levemente roxo escuro
                renderAuraBox(ps, buf, entity, 0.12f, 0.0f, 0.18f, alpha * 0.4f, ageInTicks, 1.34f);
            }
        }

        /**
         * Desenha um cubo de aura ao redor da entidade.
         * scale = multiplicador do bounding box (1.18 = 18% maior que a entidade)
         */
        private void renderAuraBox(PoseStack ps, MultiBufferSource buf,
                                   EnzoGlacial entity, float r, float g, float b, float a,
                                   float age, float scale) {
            // Usa RenderType translucido para o glow
            VertexConsumer vc = buf.getBuffer(RenderType.lightning());

            ps.pushPose();
            // Centraliza no entity e aplica escala
            ps.scale(scale, scale, scale);

            Matrix4f mat = ps.last().pose();

            // Offsets do cubo (em coordenadas locais do modelo, de -0.5 a +0.5 por bloco)
            // O modelo zombie tem ~0.4 de largura e ~0.95 de altura em unidades de modelo
            float hw = 0.35f;  // meia-largura
            float h  = 0.95f;  // altura
            float y0 = -0.01f; // base levemente abaixo dos pés
            float y1 = h;      // topo

            // Face frontal
            quad(vc, mat, -hw, y0, -hw, hw, y0, -hw, hw, y1, -hw, -hw, y1, -hw, r, g, b, a);
            // Face traseira
            quad(vc, mat,  hw, y0, hw, -hw, y0, hw, -hw, y1, hw,  hw, y1, hw, r, g, b, a);
            // Esquerda
            quad(vc, mat, -hw, y0, hw, -hw, y0, -hw, -hw, y1, -hw, -hw, y1, hw, r, g, b, a);
            // Direita
            quad(vc, mat,  hw, y0, -hw,  hw, y0, hw,  hw, y1, hw,   hw, y1, -hw, r, g, b, a);
            // Topo
            quad(vc, mat, -hw, y1, -hw, hw, y1, -hw, hw, y1, hw, -hw, y1, hw, r, g, b, a);
            // Base
            quad(vc, mat, -hw, y0, hw, hw, y0, hw, hw, y0, -hw, -hw, y0, -hw, r, g, b, a);

            ps.popPose();
        }

        private void quad(VertexConsumer vc, Matrix4f mat,
                          float x0, float y0, float z0,
                          float x1, float y1, float z1,
                          float x2, float y2, float z2,
                          float x3, float y3, float z3,
                          float r, float g, float b, float a) {
            vc.vertex(mat, x0, y0, z0).color(r, g, b, a).endVertex();
            vc.vertex(mat, x1, y1, z1).color(r, g, b, a).endVertex();
            vc.vertex(mat, x2, y2, z2).color(r, g, b, a).endVertex();
            vc.vertex(mat, x3, y3, z3).color(r, g, b, a).endVertex();
        }
    }
}
