// [ServerEvents.java] — Integra expansão + sistema de classes + Rei do Gelo
package com.valdoria.rpg.event;

import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.entity.MalacharEntity;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.network.OpenFactionPacket;
import com.valdoria.rpg.quest.QuestManager;
import com.valdoria.rpg.registry.ModItems;
import com.valdoria.rpg.world.CastleBuilder;
import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.ForgeRegistries;

@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID)
public class ServerEvents {

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (!(e.getEntity() instanceof ServerPlayer sp)) return;
        if (!PlayerData.hasFlag(sp, "starter")) {
            PlayerData.setFlag(sp, "starter");
            PlayerData.setMana(sp, PlayerData.MAX_MANA);
            QuestManager.give(sp, new ItemStack(ModItems.FOUNDATION_STONE.get()));
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                    "§6Bem-vindo a Valdoria, Enzo. Use /valdoria quest. P=Perfil M=Mapa H=HUD C=Classe"));
        }
        ModNetwork.sync(sp);
        if (PlayerData.getCompleted(sp) >= 10 && PlayerData.getFaction(sp) == 0) {
            ModNetwork.sendTo(sp, new OpenFactionPacket());
        }
    }

    @SubscribeEvent
    public static void onClone(PlayerEvent.Clone e) {
        var old = e.getOriginal().getPersistentData();
        if (old.contains(Player.PERSISTED_NBT_TAG, 10)) {
            e.getEntity().getPersistentData().put(Player.PERSISTED_NBT_TAG,
                    old.getCompound(Player.PERSISTED_NBT_TAG).copy());
        }
    }

    @SubscribeEvent
    public static void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer sp) ModNetwork.sync(sp);
    }

    @SubscribeEvent
    public static void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.side != LogicalSide.SERVER) return;
        if (!(e.player instanceof ServerPlayer sp)) return;

        // Tick do cooldown do Redemoinho
        if (sp.tickCount % 20 == 0) {
            PlayerData.tickWhirlpool(sp);
        }

        if (sp.tickCount % 20 == 0) {
            // Regen de mana: Mago regen +50%, Arqueiro normal, outros normal
            float manaRegen = PlayerData.getFaction(sp) == 1 ? 3.0F : 2.0F;
            if (PlayerData.getPlayerClass(sp) == PlayerData.CLASS_MAGO) manaRegen *= 1.5F;
            PlayerData.addMana(sp, manaRegen);
            QuestManager.tick(sp);
            ModNetwork.sync(sp);
            applyNiveriaDebuffs(sp);
            checkMalacharProximity(sp);
        }
        if (sp.tickCount % 1200 == 600) horde(sp);
        if (sp.tickCount % 200 == 0) checkCastleProgression(sp);
        if (sp.tickCount % 200 == 100) checkNiveriaHunger(sp);
        if (sp.tickCount % 20 == 10) applyClassPassives(sp);
    }

    /** Aplica passivas de classe a cada segundo. */
    private static void applyClassPassives(ServerPlayer sp) {
        int cls = PlayerData.getPlayerClass(sp);
        if (cls == PlayerData.CLASS_ARQUEIRO) {
            // Arqueiro: +10% velocidade, menos fome (reduz exaustão)
            sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 25, 0, true, false));
        }
        if (cls == PlayerData.CLASS_GUERREIRO) {
            // Guerreiro: leve regeneração de vida em combate (HP > 5)
            if (sp.getHealth() > 5 && sp.getHealth() < sp.getMaxHealth()) {
                sp.heal(0.05F);
            }
        }
    }

    /** Debuffs de Nivéria — Rei do Gelo tem 40% menos duração. */
    private static void applyNiveriaDebuffs(ServerPlayer sp) {
        if (!sp.level().dimension().equals(NiveriaDimension.NIVERIA)) return;
        boolean isIceKing = PlayerData.getPlayerClass(sp) == PlayerData.CLASS_REI_GELO;
        int dur = isIceKing ? 36 : 60; // 40% menos se Rei do Gelo
        int amp = isIceKing ? 0 : 0;  // mesma amplitude, só duração menor

        sp.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, dur, amp, true, false));
        sp.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, dur, amp, true, false));

        if (!PlayerData.hasFlag(sp, "portal_niveria_entered")) {
            PlayerData.setFlag(sp, "portal_niveria_entered");
            String msg = isIceKing
                    ? "§b❄ Você entrou em Nivéria. Como Rei do Gelo, o frio te afeta apenas 40%."
                    : "§b❄ Você entrou em Nivéria. O frio extremo drena suas forças...";
            sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
        }
    }

    private static void checkNiveriaHunger(ServerPlayer sp) {
        if (!sp.level().dimension().equals(NiveriaDimension.NIVERIA)) return;
        boolean isIceKing = PlayerData.getPlayerClass(sp) == PlayerData.CLASS_REI_GELO;
        // Rei do Gelo: 40% menos exaustão de fome
        float exhaustion = isIceKing ? 1.2F : 2.0F;
        sp.getFoodData().addExhaustion(exhaustion);
    }

    private static void checkMalacharProximity(ServerPlayer sp) {
        if (sp.level().dimension() != Level.OVERWORLD) return;
        if (PlayerData.getCompleted(sp) != 49) return;
        if (PlayerData.hasFlag(sp, "malachar_spawned")) return;
        BlockPos spawn = sp.serverLevel().getSharedSpawnPos();
        double dist = sp.distanceToSqr(spawn.getX(), spawn.getY(), spawn.getZ());
        if (dist < 30.0D * 30.0D) {
            MalacharEntity.spawnNear(sp);
            PlayerData.setFlag(sp, "malachar_spawned");
        }
    }

    private static void checkCastleProgression(ServerPlayer sp) {
        if (sp.level().dimension() != Level.OVERWORLD) return;
        int done = PlayerData.getCompleted(sp);
        if (done % 5 != 0 || done == 0) return;
        int stage = done / 5;
        if (stage > 9) return;
        String flagKey = "castle_stage_" + stage;
        if (PlayerData.hasFlag(sp, flagKey)) return;
        PlayerData.setFlag(sp, flagKey);
        ServerLevel level = sp.serverLevel();
        BlockPos origin = level.getSharedSpawnPos();
        CastleBuilder.build(level, origin, stage);
        sp.sendSystemMessage(net.minecraft.network.chat.Component.literal(
                "§e§l🏰 O castelo de Valdoria avançou para o Estágio " + stage + "!"));
    }

    private static void horde(ServerPlayer sp) {
        int done = PlayerData.getCompleted(sp);
        if (done < 11 || done >= 49) return;
        ServerLevel lvl = sp.serverLevel();
        int n = 2 + done / 10;
        for (int i = 0; i < n; i++) {
            double x = sp.getX() + (lvl.random.nextDouble() - 0.5D) * 24.0D;
            double z = sp.getZ() + (lvl.random.nextDouble() - 0.5D) * 24.0D;
            Mob mob;
            if (lvl.dimension() == Level.NETHER && done >= 20) {
                Piglin pg = EntityType.PIGLIN.create(lvl);
                if (pg == null) continue;
                pg.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.GOLDEN_SWORD));
                mob = pg;
            } else if (i % 2 == 0) {
                mob = EntityType.ZOMBIE.create(lvl);
            } else {
                mob = EntityType.SKELETON.create(lvl);
            }
            if (mob == null) continue;
            mob.moveTo(x, sp.getY(), z, lvl.random.nextFloat() * 360.0F, 0.0F);
            if (!lvl.noCollision(mob)) continue;
            mob.setTarget(sp);
            lvl.addFreshEntity(mob);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer sp) {
            ResourceLocation key = ForgeRegistries.ENTITY_TYPES.getKey(e.getEntity().getType());
            if (key != null) PlayerData.addKill(sp, key.toString());
        }
    }

    @SubscribeEvent
    public static void onHurt(LivingHurtEvent e) {
        if (!(e.getSource().getEntity() instanceof ServerPlayer sp)) return;
        int cls = PlayerData.getPlayerClass(sp);
        // Demônio: +15% dano
        if (PlayerData.getFaction(sp) == 2) e.setAmount(e.getAmount() * 1.15F);
        // Mago: +10% dano (stacks com demônio)
        if (cls == PlayerData.CLASS_MAGO) e.setAmount(e.getAmount() * 1.10F);
        // Rei do Gelo: dano base +8% (mais sutil, o poder real é o Redemoinho)
        if (cls == PlayerData.CLASS_REI_GELO) e.setAmount(e.getAmount() * 1.08F);
    }
}
