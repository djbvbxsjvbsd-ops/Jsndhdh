package com.valdoria.rpg.client;

public final class ClientData {
    public static int faction       = 0;
    public static int completed     = 0;
    public static float mana        = 100.0F;
    public static float maxMana     = 100.0F;
    public static boolean hudVisible = true;
    public static boolean inNiveria = false;
    public static int fragmentosGlaciais = 0;

    // Classe do personagem
    public static int playerClass      = 0;
    public static int classChanges     = 0;   // trocas já usadas
    public static int whirlpoolCooldown = 0;  // ticks restantes

    private ClientData() {}

    public static void update(int f, int c, float m, float mm) {
        faction = f; completed = c; mana = m; maxMana = mm;
    }
    public static void updateNiveria(boolean niv, int frags) {
        inNiveria = niv;
        fragmentosGlaciais = frags;
    }
    public static void updateClass(int cls, int changes, int whirlCd) {
        playerClass = cls; classChanges = changes; whirlpoolCooldown = whirlCd;
    }

    public static int act() { return Math.min(10, completed / 10 + 1); }

    public static String factionName() {
        return faction == 1 ? "Anjo (Luz)" : faction == 2 ? "Demônio (Trevas)" : "Nenhuma";
    }
    public static String dimensionName() {
        return inNiveria ? "Nivéria (Mundo Congelante)" : "Overworld (Valdoria)";
    }
    public static String className() {
        return switch (playerClass) {
            case 1  -> "Guerreiro";
            case 2  -> "Mago";
            case 3  -> "Arqueiro";
            case 4  -> "Rei Secreto do Gelo";
            default -> "Sem Classe";
        };
    }
    public static boolean isIceKing() { return playerClass == 4; }
}
