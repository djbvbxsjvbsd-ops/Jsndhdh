// [ValdoriaCommands.java] — SUBSTITUI o original; adiciona /valdoria castle, niveria, back, resetquests, give
package com.valdoria.rpg.command;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.entity.MalacharEntity;
import com.valdoria.rpg.network.ModNetwork;
import com.valdoria.rpg.quest.Quest;
import com.valdoria.rpg.quest.QuestData;
import com.valdoria.rpg.quest.QuestManager;
import com.valdoria.rpg.registry.ModItems;
import com.valdoria.rpg.world.CastleBuilder;
import com.valdoria.rpg.world.NiveriaDimension;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.List;
@Mod.EventBusSubscriber(modid = ValdoriaMod.MODID)
public class ValdoriaCommands {
    @SubscribeEvent
    public static void register(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("valdoria")
                .then(Commands.literal("quest").executes(ctx -> quest(ctx.getSource())))
                .then(Commands.literal("setquest").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("n", IntegerArgumentType.integer(0, 101))
                                .executes(ctx -> setQuest(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "n")))))
                .then(Commands.literal("boss").requires(s -> s.hasPermission(2)).executes(ctx -> boss(ctx.getSource())))
                .then(Commands.literal("dumpboss").requires(s -> s.hasPermission(2)).executes(ctx -> dumpBoss(ctx.getSource())))
                .then(Commands.literal("castle").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("stage", IntegerArgumentType.integer(1, 9))
                                .executes(ctx -> castle(ctx.getSource(), IntegerArgumentType.getInteger(ctx, "stage")))))
                .then(Commands.literal("niveria").requires(s -> s.hasPermission(2)).executes(ctx -> goNiveria(ctx.getSource())))
                .then(Commands.literal("back").executes(ctx -> goBack(ctx.getSource())))
                .then(Commands.literal("resetquests").requires(s -> s.hasPermission(2)).executes(ctx -> resetQuests(ctx.getSource())))
                .then(Commands.literal("give").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("item", StringArgumentType.word())
                                .executes(ctx -> giveItem(ctx.getSource(), StringArgumentType.getString(ctx, "item"))))));
    }
    private static int quest(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        int done = PlayerData.getCompleted(p);
        if (done >= QuestData.size()) {
            src.sendSuccess(() -> Component.literal("§6A Saga do Enzo está completa!"), false);
            return 1;
        }
        Quest q = QuestData.get(done + 1);
        src.sendSuccess(() -> Component.literal("§e" + QuestData.actName(q.act())
                + "\n§fMissão " + q.id() + "/101: " + q.title() + "\n§7" + q.objective()), false);
        return 1;
    }
    private static int setQuest(CommandSourceStack src, int n) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        PlayerData.setCompleted(p, n);
        ModNetwork.sync(p);
        src.sendSuccess(() -> Component.literal("Missões concluídas = " + n), true);
        return 1;
    }
    private static int boss(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        MalacharEntity.spawnNear(p);
        return 1;
    }
    private static int dumpBoss(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        List<MalacharEntity> list = p.serverLevel().getEntitiesOfClass(MalacharEntity.class, p.getBoundingBox().inflate(100.0D));
        if (list.isEmpty()) {
            src.sendSuccess(() -> Component.literal("Nenhum Malachar por perto."), false);
            return 0;
        }
        CompoundTag tag = new CompoundTag();
        list.get(0).save(tag);
        float hp = tag.getFloat("Health");
        int phase = tag.getInt("MalacharPhase");
        src.sendSuccess(() -> Component.literal("Malachar: HP " + hp + " | fase " + phase), false);
        return 1;
    }
    private static int castle(CommandSourceStack src, int stage) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ServerLevel level = p.serverLevel();
        BlockPos origin = level.getSharedSpawnPos();
        CastleBuilder.build(level, origin, stage);
        src.sendSuccess(() -> Component.literal("§e🏰 Castelo construído até o estágio " + stage), true);
        return 1;
    }
    private static int goNiveria(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        MinecraftServer server = src.getServer();
        ServerLevel niveriaLevel = server.getLevel(NiveriaDimension.NIVERIA);
        if (niveriaLevel == null) {
            src.sendSuccess(() -> Component.literal("§cDimensão Nivéria não encontrada. Verifique o JSON da dimensão."), false);
            return 0;
        }
        p.teleportTo(niveriaLevel, niveriaLevel.getSharedSpawnPos().getX(), niveriaLevel.getSharedSpawnPos().getY(), niveriaLevel.getSharedSpawnPos().getZ(), 0.0F, 0.0F);
        p.sendSystemMessage(Component.literal("§b§lBEM-VINDO A NIVÉRIA. O frio corrói sua alma."));
        return 1;
    }
    private static int goBack(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        MinecraftServer server = src.getServer();
        ServerLevel overworld = server.getLevel(Level.OVERWORLD);
        if (overworld == null) return 0;
        BlockPos spawn = overworld.getSharedSpawnPos();
        p.teleportTo(overworld, spawn.getX(), spawn.getY(), spawn.getZ(), 0.0F, 0.0F);
        p.sendSystemMessage(Component.literal("§aVoltou ao Overworld."));
        return 1;
    }
    private static int resetQuests(CommandSourceStack src) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        PlayerData.setCompleted(p, 0);
        ModNetwork.sync(p);
        src.sendSuccess(() -> Component.literal("§c⚠ Progresso de quests zerado!"), true);
        return 1;
    }
    private static int giveItem(CommandSourceStack src, String itemName) throws CommandSyntaxException {
        ServerPlayer p = src.getPlayerOrException();
        ItemStack stack = switch (itemName.toLowerCase()) {
            case "chave_glacial" -> new ItemStack(ModItems.CHAVE_GLACIAL.get());
            case "cristal_glacial" -> new ItemStack(ModItems.CRISTAL_GLACIAL.get(), 4);
            case "fragmento_glacial" -> new ItemStack(ModItems.FRAGMENTO_GLACIAL.get(), 4);
            case "espada_glacial" -> new ItemStack(ModItems.ESPADA_GLACIAL.get());
            case "coracao_niveria" -> new ItemStack(ModItems.CORACAO_NIVERIA.get());
            case "coroa_niveria" -> new ItemStack(ModItems.COROA_NIVERIA.get());
            case "chave_real" -> new ItemStack(ModItems.CHAVE_REAL.get());
            case "armadura_glacial" -> {
                QuestManager.give(p, new ItemStack(ModItems.ARMADURA_GLACIAL_HELMET.get()));
                QuestManager.give(p, new ItemStack(ModItems.ARMADURA_GLACIAL_CHESTPLATE.get()));
                QuestManager.give(p, new ItemStack(ModItems.ARMADURA_GLACIAL_LEGGINGS.get()));
                QuestManager.give(p, new ItemStack(ModItems.ARMADURA_GLACIAL_BOOTS.get()));
                src.sendSuccess(() -> Component.literal("§bArmadura Glacial completa dada."), true);
                yield ItemStack.EMPTY;
            }
            default -> {
                src.sendSuccess(() -> Component.literal("§cItem desconhecido: " + itemName + ". Opções: chave_glacial, cristal_glacial, fragmento_glacial, espada_glacial, coracao_niveria, coroa_niveria, chave_real, armadura_glacial"), false);
                yield ItemStack.EMPTY;
            }
        };
        if (!stack.isEmpty()) {
            QuestManager.give(p, stack);
            String name = itemName;
            src.sendSuccess(() -> Component.literal("§bItem dado: " + name), true);
        }
        return 1;
    }
}
