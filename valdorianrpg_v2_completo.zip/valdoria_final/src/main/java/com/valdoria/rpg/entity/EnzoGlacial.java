// [EnzoGlacial.java]
package com.valdoria.rpg.entity;
import com.valdoria.rpg.data.PlayerData;
import com.valdoria.rpg.registry.ModEntities;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import java.util.UUID;
public class EnzoGlacial extends Zombie {
    private static final UUID RAGE_ID = UUID.fromString("7c3a1b2e-4f5d-6e7a-8b9c-0d1e2f3a4b5c");
    private final ServerBossEvent bossBar = new ServerBossEvent(
            Component.literal("Enzo Glacial"), BossEvent.BossBarColor.BLUE, BossEvent.BossBarOverlay.NOTCHED_10);
    private int phase = 1;
    public EnzoGlacial(EntityType<? extends EnzoGlacial> type, Level level) {
        super(type, level);
        this.setCustomName(Component.literal("Enzo Glacial"));
        this.setPersistenceRequired();
        this.xpReward = 1000;
    }
    public static AttributeSupplier.Builder createAttributes() {
        return Zombie.createAttributes()
                .add(Attributes.MAX_HEALTH, 400.0D)
                .add(Attributes.ATTACK_DAMAGE, 15.0D)
                .add(Attributes.ARMOR, 12.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 64.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D);
    }
    public static EnzoGlacial spawnNear(ServerPlayer p) {
        ServerLevel lvl = p.serverLevel();
        EnzoGlacial e = ModEntities.ENZO_GLACIAL.get().create(lvl);
        if (e == null) return null;
        e.moveTo(p.getX() + 6.0D, p.getY(), p.getZ(), 0.0F, 0.0F);
        e.setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(Items.DIAMOND_SWORD));
        e.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.DIAMOND_HELMET));
        e.setItemSlot(EquipmentSlot.CHEST, new ItemStack(Items.DIAMOND_CHESTPLATE));
        e.setItemSlot(EquipmentSlot.LEGS, new ItemStack(Items.DIAMOND_LEGGINGS));
        e.setItemSlot(EquipmentSlot.FEET, new ItemStack(Items.DIAMOND_BOOTS));
        e.setTarget(p);
        lvl.addFreshEntity(e);
        e.playSound(SoundEvents.WITHER_SPAWN.value(), 1.0F, 1.2F);
        return e;
    }
    @Override
    public void startSeenByPlayer(ServerPlayer p) { super.startSeenByPlayer(p); bossBar.addPlayer(p); }
    @Override
    public void stopSeenByPlayer(ServerPlayer p) { super.stopSeenByPlayer(p); bossBar.removePlayer(p); }
    @Override
    protected void customServerAiStep() {
        super.customServerAiStep();
        float pct = getHealth() / getMaxHealth();
        bossBar.setProgress(pct);
        if (phase == 1 && pct <= 0.6F) startPhase2();
        else if (phase == 2 && pct <= 0.3F) startPhase3();
        if (phase == 2 && tickCount % 60 == 0) {
            for (Player p : level().getEntitiesOfClass(Player.class, getBoundingBox().inflate(8.0D))) {
                p.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 3));
                p.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 1));
            }
        }
        if (phase == 3) {
            ensureRage();
            if (tickCount % 40 == 0 && level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.SNOWFLAKE, getX(), getY() + 1.0D, getZ(), 30, 1.5D, 1.0D, 1.5D, 0.05D);
            }
        }
    }
    private void startPhase2() {
        phase = 2;
        bossBar.setName(Component.literal("Enzo Glacial - Fúria do Gelo"));
        playSound(SoundEvents.ELDER_GUARDIAN_CURSE.value(), 1.0F, 0.8F);
    }
    private void startPhase3() {
        phase = 3;
        bossBar.setName(Component.literal("Enzo Glacial - FORMA FINAL"));
        ensureRage();
        playSound(SoundEvents.WITHER_DEATH.value(), 1.0F, 0.6F);
    }
    private void ensureRage() {
        var attr = getAttribute(Attributes.MOVEMENT_SPEED);
        if (attr != null && attr.getModifier(RAGE_ID) == null) {
            attr.addTransientModifier(new AttributeModifier(RAGE_ID, "enzo_glacial_rage", 0.5D, AttributeModifier.Operation.MULTIPLY_TOTAL));
        }
    }
    @Override
    public void die(DamageSource src) {
        super.die(src);
        if (level() instanceof ServerLevel sl) {
            for (ServerPlayer p : sl.players()) {
                if (p.distanceToSqr(this) < 150.0D * 150.0D) {
                    PlayerData.setFlag(p, "enzo_glacial_dead");
                    p.sendSystemMessage(Component.literal("§b§lENZO GLACIAL FOI DERROTADO. Nivéria está salva."));
                }
            }
        }
        bossBar.removeAllPlayers();
    }
    @Override protected boolean isSunSensitive() { return false; }
    @Override protected boolean convertsInWater() { return false; }
    @Override
    public void addAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("EnzoGlacialPhase", phase);
    }
    @Override
    public void readAdditionalSaveData(net.minecraft.nbt.CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        phase = Math.max(1, tag.getInt("EnzoGlacialPhase"));
    }
}
