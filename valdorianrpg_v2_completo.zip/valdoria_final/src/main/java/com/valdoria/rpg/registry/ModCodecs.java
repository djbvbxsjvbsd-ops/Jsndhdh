// [ModCodecs.java] src/main/java/com/valdoria/rpg/registry/ModCodecs.java
package com.valdoria.rpg.registry;
import com.valdoria.rpg.ValdoriaMod;
import com.valdoria.rpg.world.NiveriaChunkGenerator;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.chunk.ChunkGenerator;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
public final class ModCodecs {
    public static final DeferredRegister<com.mojang.serialization.Codec<? extends ChunkGenerator>> CHUNK_GENERATORS =
            DeferredRegister.create(Registries.CHUNK_GENERATOR, ValdoriaMod.MODID);
    public static final RegistryObject<com.mojang.serialization.Codec<? extends ChunkGenerator>> NIVERIA_GENERATOR =
            CHUNK_GENERATORS.register("niveria", () -> NiveriaChunkGenerator.CODEC);
    private ModCodecs() {}
}
